package com.zte.sdn.oscp.algorithm.simulator.xml;

import com.zte.sdn.oscp.algorithm.simulator.model.TestSchedule;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

@XmlRootElement(name = "schedules")
public class ScheduleXmlWrap {
    private ObservableList<TestSchedule> schedules = FXCollections.observableArrayList();

    @XmlElement(name = "schedule")
    public ObservableList<TestSchedule> getSchedules() {
        return schedules;
    }

    public void setSchedules(ObservableList<TestSchedule> schedules) {
        this.schedules = schedules;
    }
}
