package com.zte.sdn.oscp.algorithm.simulator.controller;

import com.zte.sdn.oscp.algorithm.simulator.MainApp;
import com.zte.sdn.oscp.algorithm.simulator.model.TestEdge;
import com.zte.sdn.oscp.algorithm.simulator.model.TestGraph;
import com.zte.sdn.oscp.algorithm.simulator.model.TestRequest;
import com.zte.sdn.oscp.algorithm.simulator.model.TestRoute;
import com.zte.sdn.oscp.algorithm.simulator.model.TestSchedule;
import com.zte.sdn.oscp.algorithm.simulator.model.TestVertex;

import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableCell;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class RequestApplyController {
    @FXML
    ScrollPane scrollPane;
    @FXML
    AnchorPane pane;
    private Stage dialog;
    private boolean okClicked = false;
    @FXML
    private TreeTableView<TestRoute> applyView;
    @FXML
    private TreeTableColumn<TestRoute, String> nameCol;
    @FXML
    private TreeTableColumn<TestRoute, String> requestStartCol;
    @FXML
    private TreeTableColumn<TestRoute, String> requestEndCol;
    @FXML
    private TreeTableColumn<TestRoute, Integer> hopsCol;
    @FXML
    private TreeTableColumn<TestRoute, String> applyCol;
    private MainApp mainApp;

    public void setDialogStage(Stage stage) {
        dialog = stage;
    }

    public boolean isOkClicked() {
        return okClicked;
    }

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

    @FXML
    public void initialize() {
        nameCol.setCellValueFactory(
            (TreeTableColumn.CellDataFeatures<TestRoute, String> param) ->
                new ReadOnlyStringWrapper(param.getValue().getValue().getName())
        );
        requestStartCol.setCellValueFactory(
            (TreeTableColumn.CellDataFeatures<TestRoute, String> param) ->
                new ReadOnlyStringWrapper(param.getValue().getValue().getRequestStart())
        );
        requestEndCol.setCellValueFactory(
            (TreeTableColumn.CellDataFeatures<TestRoute, String> param) ->
                new ReadOnlyStringWrapper(param.getValue().getValue().getRequestEnd())
        );
        // TODO Observable<Integer> => Observable<Number> 转换?
        hopsCol.setCellValueFactory(
            (TreeTableColumn.CellDataFeatures<TestRoute, Integer> param) ->
                (new ReadOnlyIntegerWrapper(param.getValue().getValue().getHops())).asObject()
        );
        hopsCol.setCellFactory((TreeTableColumn<TestRoute, Integer> param) ->
            new MyTreeTableCell()
        );

        applyCol.setCellValueFactory(
            (TreeTableColumn.CellDataFeatures<TestRoute, String> param) ->
                new ReadOnlyStringWrapper(param.getValue().getValue().getApply())
        );
        // 使用checkbox
        //applyCol.setCellFactory(CheckBoxTreeTableCell.forTreeTableColumn(applyCol));
        applyCol.setCellFactory((TreeTableColumn<TestRoute, String> param) ->
            new MyCheckBoxTreeTableCell()
        );

        applyCol.setEditable(true);

        applyView.setEditable(true);

        GraphManageController.initGraphView(scrollPane, pane);

        applyView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<TreeItem<TestRoute>>() {
            @Override
            public void changed(ObservableValue<? extends TreeItem<TestRoute>> observable, TreeItem<TestRoute> oldValue, TreeItem<TestRoute> newValue) {
                if (null != newValue) {
                    ObservableList<String> infos = FXCollections.observableArrayList();
                    TestRequest request = newValue.getValue().getBelongRequest();
                    // 选中了route
                    if (null != request) {
                        TestSchedule schedule = mainApp.getSchedule(newValue.getParent().getParent().getValue().getName());
                        if (null == schedule) {
                            // 错误数据
                            return;
                        }
                        // 重新加载graph
                        mainApp.loadGraph();
                        TestGraph graph = mainApp.getGraph(schedule.getGraphName());
                        if (null == graph) {
                            // 错误数据
                            return;
                        }
                        GraphManageController.showGraphView(scrollPane, pane, graph, null, null, null, null);
                        // 高亮az点
                        TestVertex vStart = (TestVertex) graph.getVertex(request.getRequestStart());
                        TestVertex vEnd = (TestVertex) graph.getVertex(request.getRequestEnd());
                        vStart.getShape().setHighlight();
                        vEnd.getShape().setHighlight();
                        // 高亮路由
                        for (String edgeId : newValue.getValue().getLcs()) {
                            TestEdge edge = (TestEdge) graph.getEdge(edgeId);
                            edge.getSrc().getShape().setHighlight();
                            edge.getDst().getShape().setHighlight();
                            edge.getShape().setHighlight();
                        }
                        return;
                    }
                    // 选中了request
                    if (null != newValue.getValue().getRequestStart()
                        && !newValue.getValue().getRequestStart().isEmpty()) {
                        TestSchedule schedule = mainApp.getSchedule(newValue.getParent().getValue().getName());
                        if (null == schedule) {
                            // 错误数据
                            return;
                        }
                        request = schedule.getRequest(newValue.getValue().getName());
                        if (null == request) {
                            // 错误数据
                            return;
                        }
                        // 重新加载graph
                        mainApp.loadGraph();
                        TestGraph graph = mainApp.getGraph(schedule.getGraphName());
                        GraphManageController.showGraphView(scrollPane, pane, graph, null, null, null, null);
                        // 高亮az点
                        TestVertex vStart = (TestVertex) graph.getVertex(request.getRequestStart());
                        TestVertex vEnd = (TestVertex) graph.getVertex(request.getRequestEnd());
                        vStart.getShape().setHighlight();
                        vEnd.getShape().setHighlight();
                        return;
                    } else {
                        // 选中了schedule
                        TestSchedule schedule = mainApp.getSchedule(newValue.getValue().getName());
                        if (null == schedule) {
                            // 错误数据
                            return;
                        }
                        // 重新加载graph
                        mainApp.loadGraph();
                        TestGraph graph = mainApp.getGraph(schedule.getGraphName());
                        GraphManageController.showGraphView(scrollPane, pane, graph, null, null, null, null);
                        return;
                    }
                }
                // 其他情况, 清空
                GraphManageController.clearGraphView(pane, null);
            }
        });
    }

    public void init() {
        TreeItem<TestRoute> rootItem = new TreeItem<>(new TestRoute());
        applyView.setRoot(rootItem);
        applyView.setShowRoot(false);
        mainApp.getAllData().stream().forEach(schedule -> {
            if (schedule.isNeedExecuteSchedule()) { // 是否执行
                TestRoute scheduleItemData = new TestRoute(schedule.getScheduleName());
                // 第一层
                TreeItem<TestRoute> scheduleItem = new TreeItem<>(scheduleItemData);
                scheduleItem.setExpanded(true);
                rootItem.getChildren().add(scheduleItem);
                for (TestRequest requestData : schedule.getRequests()) {
                    if (requestData.getNeedExecuteRequest()) { // 是否执行
                        // 忽略已经创建了的业务
                        if (!requestData.isRequest()) {
                            continue;
                        }
                        TestRoute requestItemData = new TestRoute();
                        requestItemData.setName(requestData.getRequestId());
                        requestItemData.setRequestStart(requestData.getRequestStart());
                        requestItemData.setRequestEnd(requestData.getRequestEnd());
                        // 第二层
                        TreeItem<TestRoute> requestItem = new TreeItem<>(requestItemData);
                        requestItem.setExpanded(true);
                        scheduleItem.getChildren().add(requestItem);
                        for (TestRoute requestRouteData : requestData.getRoute()) {
                            TestRoute routeItemData = new TestRoute();
                            routeItemData.setName(requestRouteData.getName());
                            routeItemData.setRequestStart(requestRouteData.getRequestStart());
                            routeItemData.setRequestEnd(requestRouteData.getRequestEnd());
                            routeItemData.setLcs(requestRouteData.getLcs());
                            routeItemData.setBelongRequest(requestRouteData.getBelongRequest());

                            // 默认选择第一个route结果
                            if (requestRouteData == requestData.getRoute().get(0)) {
                                routeItemData.setApply("是");
                                // 可能是无效路由, 就设置成""处理成不显示checkbox
                                if (requestRouteData.getRequestStart().isEmpty() ||
                                    requestRouteData.getRequestEnd().isEmpty()) {
                                    routeItemData.setApply("");
                                }
                            } else {
                                routeItemData.setApply("否");
                            }
                            // 第三层
                            TreeItem<TestRoute> routeItem = new TreeItem<>(routeItemData);
                            requestItem.getChildren().add(routeItem);
                        }
                    }
                }
            }
        });
    }

    @FXML
    public void handleOk() {
        // TODO
        reset();

        for (TreeItem<TestRoute> scheduleItem : applyView.getRoot().getChildren()) {
            TestSchedule schedule = mainApp.getSchedule(scheduleItem.getValue().getName());
            // 重新加载graph
            mainApp.loadGraph();
            TestGraph graph = mainApp.getGraph(schedule.getGraphName());
            for (TreeItem<TestRoute> requestItem : scheduleItem.getChildren()) {
                // 这个request应该和下面route中记录的一致
                TestRequest request = mainApp.getRequest(schedule.getScheduleName(), requestItem.getValue().getName());
                // 忽略已经创建了的业务
                if (!request.isRequest()) {
                    continue;
                }
                boolean bChanged = false;
                for (TreeItem<TestRoute> routeItem : requestItem.getChildren()) {
                    TestRoute route = routeItem.getValue();
                    if (route.getApply().equals("是")) {
                        bChanged = true;
                        route.getBelongRequest().getRoute().clear();
                        route.getBelongRequest().getRoute().add(route);
                        // 更新edge的带宽信息
                        for (String edgeId : route.getLcs()) {
                            TestEdge edge = (TestEdge) graph.getEdge(edgeId);
                            edge.getEdgeAdditionalAttrs().setBwUsed(edge.getEdgeAdditionalAttrs().getBwUsed() + (Double.valueOf(request.getBandwidth())));
                            edge.getEdgeAdditionalAttrs().setBwUnused(edge.getEdgeAdditionalAttrs().getBwUnused() - (Double.valueOf(request.getBandwidth())));
                            edge.getEdgeAdditionalAttrs().setBwUtilization(edge.getEdgeAdditionalAttrs().getBwUsed() / edge.getEdgeAdditionalAttrs().getBwCapacity() * 100);
                            edge.updateInfo();
                        }
                        break;
                    }
                }
                if (bChanged) {
                    request.setDeployed();
                    schedule.setCreateCounts(schedule.getCreateCounts() - 1);
                    schedule.setStockCounts(schedule.getStockCounts() + 1);

                    // 保存到graph中
                    graph.getServices().add(request);
                }
            }
        }

        // 保存一下graph数据文件
        mainApp.saveGraph();

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText("创建业务成功!\ngraph已保存, 相关带宽数据已更新!");
        alert.showAndWait();

        dialog.close();
        okClicked = true;
    }

    @FXML
    public void handleCancel() {
        // TODO
        reset();

        dialog.close();
        okClicked = false;
    }

    private void reset() {
        mainApp.getAllData().stream().forEach(schedule -> {
            if (schedule.isNeedExecuteSchedule()) { // 是否执行
                schedule.setProgress(0.0);
                for (TestRequest requestData : schedule.getRequests()) {
                    if (requestData.getNeedExecuteRequest()) { // 是否执行
                        // 新建业务才需要清除, 对于存量不需要
                        if (!requestData.isRequest()) {
                            requestData.getRoute().clear();
                        }
                    }
                }
            }
        });
    }

    final static class MyCheckBoxTreeTableCell extends TreeTableCell<TestRoute, String> {
        private final CheckBox checkBox = new CheckBox();

        public MyCheckBoxTreeTableCell() {
            checkBox.selectedProperty().addListener(new ChangeListener<Boolean>() {
                @Override
                public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                    getTreeTableRow().getItem().setApply(newValue ? "是" : "否");
                }
            });
        }

        @Override
        public void updateItem(String item, boolean empty) {
            //super.updateItem(item, empty);
            if (empty || item.isEmpty()) {
                setGraphic(null);
            } else {
                checkBox.selectedProperty().setValue(item.equals("是"));
                checkBox.setSelected(item.equals("是"));
                setGraphic(checkBox);
            }
        }
    }

    final static class MyTreeTableCell extends TreeTableCell<TestRoute, Integer> {
        @Override
        public void updateItem(Integer item, boolean empty) {
            //super.updateItem(item, empty);
            if (empty || (item == -1)) {
                setGraphic(null);
            } else {
                setItem(item);
            }
        }
    }
}
