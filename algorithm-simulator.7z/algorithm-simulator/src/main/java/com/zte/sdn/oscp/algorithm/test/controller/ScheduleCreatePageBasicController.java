package com.zte.sdn.oscp.algorithm.test.controller;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class ScheduleCreatePageBasicController extends WizardPageController {

    @FXML
    private TextField scheduleName;

    public ScheduleCreatePageBasicController() {
        super("配置schedule基本信息", "/images/wolframalpha.png");
    }

    @FXML
    public void initialize() {
    }

    public void init() {
        scheduleName.textProperty().bindBidirectional(schedule.scheduleNameProperty());
    }

    @Override
    public void handleFinish() {

    }

    @Override
    public void handleCancel() {

    }

}
