package com.zte.sdn.oscp.algorithm.simulator.model;

import javax.annotation.PostConstruct;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;

public class TestRoute {
    private TestRequest belongRequest;
    private ObservableList<String> lcs = FXCollections.observableArrayList();

    private SimpleStringProperty name = new SimpleStringProperty("");
    private SimpleStringProperty requestStart = new SimpleStringProperty("");
    private SimpleStringProperty requestEnd = new SimpleStringProperty("");
    private SimpleIntegerProperty hops = new SimpleIntegerProperty(-1);
    private SimpleStringProperty apply = new SimpleStringProperty("");

    public TestRoute() {
    }

    public TestRoute(String name) {
        this.name.setValue(name);
    }

    @PostConstruct
    void init() {
        lcs.addListener(new ListChangeListener<String>() {
            @Override
            public void onChanged(Change<? extends String> c) {
                // 增加的
                hops.setValue(hops.getValue() + c.getAddedSize());
                // 删除的
                hops.setValue(hops.getValue() - c.getRemovedSize());
            }
        });
    }

    @XmlTransient
    public TestRequest getBelongRequest() {
        return belongRequest;
    }

    public void setBelongRequest(TestRequest belongRequest) {
        this.belongRequest = belongRequest;
    }

    public String getRequestStart() {
        return requestStart.get();
    }

    public void setRequestStart(String requestStart) {
        this.requestStart.set(requestStart);
    }

    public SimpleStringProperty requestStartProperty() {
        return requestStart;
    }

    public String getName() {
        return name.get();
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public SimpleStringProperty nameProperty() {
        return name;
    }

    public String getRequestEnd() {
        return requestEnd.get();
    }

    public void setRequestEnd(String requestEnd) {
        this.requestEnd.set(requestEnd);
    }

    public SimpleStringProperty requestEndProperty() {
        return requestEnd;
    }

    public int getHops() {
        return hops.get();
    }

    public void setHops(int hops) {
        this.hops.set(hops);
    }

    public SimpleIntegerProperty hopsProperty() {
        return hops;
    }

    @XmlElementWrapper(name = "Edges")
    @XmlElement(name = "edge")
    public ObservableList<String> getLcs() {
        return lcs;
    }

    public void setLcs(ObservableList<String> lcs) {
        this.lcs = lcs;
    }

    @XmlTransient
    public String getApply() {
        return apply.get();
    }

    public void setApply(String apply) {
        this.apply.set(apply);
    }

    public SimpleStringProperty applyProperty() {
        return apply;
    }
}
