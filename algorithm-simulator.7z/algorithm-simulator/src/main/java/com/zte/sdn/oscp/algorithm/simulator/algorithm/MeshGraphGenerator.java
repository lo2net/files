package com.zte.sdn.oscp.algorithm.simulator.algorithm;

import com.zte.sdn.oscp.algorithm.simulator.model.TestGraph;
import com.zte.sdn.oscp.algorithm.simulator.model.TestVertex;

public class MeshGraphGenerator implements GraphGenerator {
    @Override
    public void generateGraph(TestGraph graph) {
        for (int i = 0; i < graph.getVertexCounts(); ++i) {
            graph.addVertex(new TestVertex(String.valueOf(i)));
        }
        // 构造一个正方形,多余放到不完整一列中
        /*
            x x x x X
            x x x x X
            x x x x X
            x x x x X
            X X X X
         */
        int vertexCnts = graph.getVertexCounts();
        // 最大id
        int maxId = vertexCnts - 1;
        int row = (int) Math.floor(Math.sqrt(vertexCnts));
        int col = row;
        int extraCnts = vertexCnts - row * row;
        if (extraCnts > 0 && extraCnts <= row) {
            row += 1;
        }
        if (extraCnts > row) {
            col += 1;
        }

        // 最左上角坐标
        double initX = 30;
        double initY = 30;
        // circle之间间隔
        double gap = 120;

        double x = initX;
        double y = initY;
        // 先构造横向的边
        for (int i = 0; i <= maxId; i += col, y += gap) {
            x = initX;
            int pre = i;
            for (int k = i; k < i + col; ++k) {
                if (pre != k) {
                    if (pre <= maxId && k <= maxId) {
                        addEdge(graph, pre, x, y, k, x + gap, y);
                        x += gap;
                    }
                }
                pre = k;
            }
        }

        // 再构造纵向的边
        x = initX;
        for (int i = 0; i < col; ++i, x += gap) {
            y = initY;
            int pre = i;
            for (int k = i; k <= maxId; k += col) {
                if (pre != k) {
                    if (pre <= maxId && k <= maxId) {
                        addEdge(graph, pre, x, y, k, x, y + gap);
                        y += gap;
                    }
                    pre = k;
                }
            }
        }
    }
}
