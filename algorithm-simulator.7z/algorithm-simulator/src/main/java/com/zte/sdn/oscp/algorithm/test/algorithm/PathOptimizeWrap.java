package com.zte.sdn.oscp.algorithm.test.algorithm;

import com.zte.sdn.oscp.algorithm.binpacking.adapter.PathOptimizationImpl;
import com.zte.sdn.oscp.algorithm.binpacking.base.PathOptHandle;
import com.zte.sdn.oscp.algorithm.binpacking.base.PathOptimizationStrategy;
import com.zte.sdn.oscp.algorithm.binpacking.result.PathOptResult;
import com.zte.sdn.oscp.algorithm.framework.constraints.impl.DefaultBwConstraint;
import com.zte.sdn.oscp.algorithm.framework.constraints.impl.DefaultConstraintBase;
import com.zte.sdn.oscp.algorithm.framework.graph.Edge;
import com.zte.sdn.oscp.algorithm.framework.graph.Vertex;
import com.zte.sdn.oscp.algorithm.framework.request.CalcPathRequestBase;
import com.zte.sdn.oscp.algorithm.framework.request.impl.CalcPathReqImpl;
import com.zte.sdn.oscp.algorithm.framework.result.Path;
import com.zte.sdn.oscp.algorithm.test.model.TestGraph;
import com.zte.sdn.oscp.algorithm.test.model.TestRequest;
import com.zte.sdn.oscp.algorithm.test.model.TestRoute;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PathOptimizeWrap {

    public PathOptResult optimize(TestGraph graph, int sceneId, int targetId) {
        // 所有已计算未部署业务
        Map<CalcPathRequestBase, List<Path>> requests = getRequestInfo(graph);
        // 所有边
        Map<String, Edge> edgeMap = getEdgeMapInfo(graph);

        PathOptHandle pathOptHandle = new TestPathOptHandle(requests, edgeMap);
        PathOptimizationImpl pathOptimizationImpl = new PathOptimizationImpl(pathOptHandle);

        PathOptimizationStrategy optStrategy = new PathOptimizationStrategy();
        optStrategy.setTypeId(sceneId);
        optStrategy.setTargetId(targetId);
        if (sceneId == 1) { // 批量业务开通路径优化
            // 所有已部署业务
            Map<CalcPathRequestBase, Path> oriDeployInfo = getOriDeployInfo(graph);
            PathOptResult result = pathOptimizationImpl.batchRequestOpen(requests, oriDeployInfo, optStrategy);
            // 返回结果
            double curGlobalBwU = result.getCurGlobalBwU();
            return result;
        } else if (sceneId == 2) { // 拥塞控制与预防优化
            PathOptResult result = pathOptimizationImpl.congestionControl(requests, optStrategy);
            // 返回结果
            double curGlobalBwU = result.getCurGlobalBwU();
            return result;
        } else if (sceneId == 3) { // 离线全局优化
            PathOptResult result = pathOptimizationImpl.globalOptimal(optStrategy);
            double curGlobalBwU = result.getCurGlobalBwU();
            return result;
        }

        return null;
    }

    private Map<String,Edge> getEdgeMapInfo(TestGraph graph) {
        Map<String, Edge> edges = new HashMap<>();
        for (Edge edge : graph.getEdges()) {
            edges.put(edge.getId(), edge);
        }
        return edges;
    }

    private Map<CalcPathRequestBase,List<Path>> getRequestInfo(TestGraph graph) {
        Map<CalcPathRequestBase,List<Path>> reqs = new HashMap<>();
        for (TestRequest request : graph.getServices()) {
            if (request.isDeployPending()) { // 读取已计算未部署的业务
                CalcPathRequestBase<Vertex, Edge> req = new CalcPathReqImpl<>();
                req.setSrc(graph.getVertex(request.getRequestStart()));
                req.setDst(graph.getVertex(request.getRequestEnd()));
                req.setServiceInfo(request.getServerInfo());
                DefaultConstraintBase constraintBase = new DefaultConstraintBase();
                constraintBase.setBwConstraint(new DefaultBwConstraint());
                req.setMasterConstraint(constraintBase);
                req.getMasterConstraint().getBwConstraint().setBandwidth(request.getBandwidth());
                // 读取路由信息
                List<Path> paths = new ArrayList<>();
                for (TestRoute route : request.getRoute()) {
                    List<Edge> edges = new ArrayList<>();
                    for (String lc : route.getLcs()) {
                        edges.add(graph.getEdge(lc));
                    }
                    Path path = new Path(
                        graph.getVertex(request.getRequestStart()),
                        graph.getVertex(request.getRequestEnd()),
                        edges);
                    paths.add(path);
                }
                reqs.put(req, paths);
            }
        }
        return reqs;
    }

    private Map<CalcPathRequestBase, Path> getOriDeployInfo(TestGraph graph) {
        Map<CalcPathRequestBase, Path> oriDeployInfo = new HashMap<CalcPathRequestBase, Path>();
        for (TestRequest request : graph.getServices()) {
            if (request.isDeployed()) { // 读取已经部署了的业务
                CalcPathRequestBase<Vertex, Edge> req = new CalcPathReqImpl<>();
                req.setSrc(graph.getVertex(request.getRequestStart()));
                req.setDst(graph.getVertex(request.getRequestEnd()));
                req.setServiceInfo(request.getServerInfo());
                DefaultConstraintBase constraintBase = new DefaultConstraintBase();
                constraintBase.setBwConstraint(new DefaultBwConstraint());
                req.setMasterConstraint(constraintBase);
                req.getMasterConstraint().getBwConstraint().setBandwidth(request.getBandwidth());
                // 读取路由信息
                TestRoute route = request.getRoute().get(0);
                if (null != route) {
                    List<Edge> edges = new ArrayList<>();
                    for (String lc : route.getLcs()) {
                        edges.add(graph.getEdge(lc));
                    }
                    Path path = new Path(
                        graph.getVertex(request.getRequestStart()),
                        graph.getVertex(request.getRequestEnd()),
                        edges);
                    oriDeployInfo.put(req, path);
                }
            }
        }
        return oriDeployInfo;
    }
}
