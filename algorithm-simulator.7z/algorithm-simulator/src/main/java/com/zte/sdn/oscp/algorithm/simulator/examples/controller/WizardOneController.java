package com.zte.sdn.oscp.algorithm.simulator.examples.controller;

public class WizardOneController implements WizardPageControllerExam {
    @Override
    public void handleFinish() {

    }

    @Override
    public void handleCancel() {

    }

    @Override
    public String getMsg() {
        return "设置第一步!";
    }
}
