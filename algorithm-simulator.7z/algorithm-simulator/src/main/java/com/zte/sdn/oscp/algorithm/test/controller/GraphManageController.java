package com.zte.sdn.oscp.algorithm.test.controller;

import com.zte.sdn.oscp.algorithm.framework.graph.Edge;
import com.zte.sdn.oscp.algorithm.framework.graph.Vertex;
import com.zte.sdn.oscp.algorithm.test.MainApp;
import com.zte.sdn.oscp.algorithm.test.model.TestEdge;
import com.zte.sdn.oscp.algorithm.test.model.TestGraph;
import com.zte.sdn.oscp.algorithm.test.model.TestVertex;
import com.zte.sdn.oscp.algorithm.test.shape.TestEdgeShape;
import com.zte.sdn.oscp.algorithm.test.shape.TestVertexShap;

import java.util.function.Consumer;

import javafx.beans.binding.Bindings;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.text.Text;
import javafx.scene.text.TextBoundsType;
import javafx.stage.Stage;
import javafx.util.Callback;

public class GraphManageController {

    private Stage dialog;
    private MainApp mainApp;

    private ObservableList<TestGraph> graphs;

    @FXML
    private TableView<TestGraph> graphView;
    @FXML
    private TableColumn name;
    @FXML
    private TableColumn topoType;
    @FXML
    private TableColumn vertexCounts;
    @FXML
    private TableColumn direction;
    @FXML
    private TableColumn averageConnectionRatio;
    @FXML
    private TableColumn bandWidth;
    @FXML
    private TableColumn timeDelay;
    @FXML
    private TableColumn weight;
    @FXML
    private TableColumn affinity;
    @FXML
    private TableColumn optimizeThreshold;

    @FXML
    private Label graphInfo;

    // 绘制grpah图形的pane
    @FXML
    AnchorPane pane;
    @FXML
    ScrollPane scrollPane;

    @FXML
    Label nodeName;
    @FXML
    Label nodeInfo;

    public void initialize() {
        name.setCellValueFactory(new PropertyValueFactory<>("name"));
        topoType.setCellValueFactory(new PropertyValueFactory<>("topoType"));
        vertexCounts.setCellValueFactory(new PropertyValueFactory<>("vertexCounts"));
        direction.setCellValueFactory(new PropertyValueFactory<>("direction"));
        averageConnectionRatio.setCellValueFactory(new PropertyValueFactory<>("averageConnectionRatio"));
        bandWidth.setCellValueFactory(new PropertyValueFactory<>("bandWidth"));
        timeDelay.setCellValueFactory(new PropertyValueFactory<>("timeDelay"));
        weight.setCellValueFactory(new PropertyValueFactory<>("weight"));
        affinity.setCellValueFactory(new PropertyValueFactory<>("affinity"));
        optimizeThreshold.setCellValueFactory(new PropertyValueFactory<>("optimizeThreshold"));

        graphInfo.setText("当前没有选中图");
        nodeName.setText("");
        nodeInfo.setText("");

        graphView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<TestGraph>() {
            @Override
            public void changed(ObservableValue<? extends TestGraph> observable, TestGraph oldValue, TestGraph newValue) {
                if (null != newValue) {
                    graphInfo.setText(newValue.getName() + " 节点数: " + newValue.getVertexCount() + ", 边数: " + newValue.getEdgeCount());
                    // 显示graph图
                    showGraphView(scrollPane, pane, newValue,
                        (Vertex v) -> {
                            nodeName.setText("点: " + v.getId());
                            nodeInfo.setText("");
                        },
                        (Edge e) -> {
                            nodeName.setText("边: " + e.getId());
                            nodeInfo.setText("　带宽：" + e.getEdgeAdditionalAttrs().getBwUnused() + "/" + e.getEdgeAdditionalAttrs().getBwCapacity());
                        }, null, null);
                    nodeName.setText("");
                    nodeInfo.setText("");
                } else {
                    // 清空graph图的显示
                    clearGraphView(pane, null);
                }
            }
        });

        // 右键菜单
        ContextMenu cmCreate = new ContextMenu();
        MenuItem create = new MenuItem("添加graph");
        create.setOnAction((ActionEvent e) -> {
            TestGraph graph = new TestGraph();
            if (mainApp.showGraphCreate(dialog, graph)) {
                graphs.add(graph);
            }
        });
        cmCreate.getItems().add(create);
        graphView.setContextMenu(cmCreate);

        ContextMenu cmDelete = new ContextMenu();
        MenuItem delete = new MenuItem("删除graph");
        delete.setOnAction((ActionEvent e) -> {
            TestGraph graph = graphView.getSelectionModel().getSelectedItem();
            if (null != graph) {
                graphs.remove(graph);
            }
        });
        cmDelete.getItems().add(delete);
        graphView.setRowFactory(tv -> {
            TableRow row = new TableRow<>();
            row.contextMenuProperty().bind(
                Bindings.when(Bindings.isNotNull(row.itemProperty()))
                    .then(cmDelete)
                    .otherwise((cmCreate)));
            return row;
            }
        );

        initGraphView(scrollPane, pane);
    }

    public static void initGraphView(ScrollPane scrollPane, AnchorPane pane) {
        scrollPane.heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                //pane.setMaxHeight(newValue.doubleValue());
                pane.setPrefHeight(newValue.doubleValue());
                //pane.resize(pane.getWidth(), newValue.doubleValue());
            }
        });
        scrollPane.widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                //pane.setMaxWidth(newValue.doubleValue());
                pane.setPrefWidth(newValue.doubleValue());
                //pane.resize(newValue.doubleValue(), pane.getHeight());
            }
        });

        // 背景设置
        pane.setBackground(new Background((new BackgroundFill(Color.rgb(0x78, 0x9e, 0xc5), null, null))));

        /*
        pane.setOnDragEntered(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                System.out.println("OnDragEntered()");

                if (event.getGestureTarget() != pane && event.getDragboard().hasString()) {
                    //
                }
                event.consume();
            }
        });
        pane.setOnDragOver(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                System.out.println("OnDragOver()");

                event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
                event.consume();
            }
        });
        pane.setOnDragDropped(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                System.out.println("OnDragDropped()");

                Dragboard db = event.getDragboard();
                if (db.hasString()) {
                    System.out.println(db.getString());
                }

                event.setDropCompleted(true);
                event.consume();
            }
        });
        */

    }

    public static void showGraphView(ScrollPane scrollPane, AnchorPane pane, TestGraph graph,
                                     Consumer<Vertex> vertexCallback,
                                     Consumer<Edge> edgeCallback,
                                     Callback<Node, ContextMenu> vertexMenuCallback,
                                     Callback<Node, ContextMenu> edgeMenuCallback) {
                                     //ContextMenu vertexMenu, ContextMenu edgeMenu) {
        clearGraphView(pane, graph);

        // TODO支持鼠标放大缩小视图, 直接更新vertex坐标, listener处理对应界面刷新
        double zoom = 1.5;
        pane.setOnScroll(new EventHandler<ScrollEvent>() {
            @Override
            public void handle(ScrollEvent event) {
                // Ctrl + Scroll 支持缩放
                if (!event.isControlDown()) {
                    return;
                }

                // 缩小
                boolean zoomin = true;
                if (event.getDeltaY() > 0) {
                   zoomin = false;
                }
                for (Vertex vertex : graph.getVertices()) {
                    TestVertex testVertex = (TestVertex)vertex;
                    double x = testVertex.getShape().getCircle().getCenterX();
                    double y = testVertex.getShape().getCircle().getCenterY();
                    testVertex.getShape().getCircle().setCenterX( zoomin ? x/zoom : x*zoom);
                    testVertex.getShape().getCircle().setCenterY( zoomin ? y/zoom : y*zoom);
                }
            }
        });

        // 遍历所有vertex
        for (Vertex vertex : graph.getVertices()) {
            TestVertexShap shape = ((TestVertex) vertex).getShape();
            shape.reset();

            final SimpleDoubleProperty offsetX = new SimpleDoubleProperty();
            final SimpleDoubleProperty offsetY = new SimpleDoubleProperty();
            final SimpleBooleanProperty dragged = new SimpleBooleanProperty(false);
            shape.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    TestVertex vertex = (TestVertex)shape.getUserData();
                    if (event.getButton().equals(MouseButton.PRIMARY)) {
                        System.out.println(vertex.getId() + " clicked!");

                        // 回调函数
                        if (null != vertexCallback) {
                            vertexCallback.accept(vertex);
                        }
                        // 选中/不选中, 不是拖动的时候
                        if (!dragged.get()) {
                            shape.switchSelected();
                        }
                    } else if (event.getButton().equals(MouseButton.SECONDARY)) {
                        // 选中/不选中, 不是拖动的时候
                        if (!dragged.get()) {
                            shape.switchSelected();
                        }
                        // 右键菜单
                        if (null != vertexMenuCallback) {
                            ContextMenu vertexMenu = vertexMenuCallback.call(shape);
                            if (null!=vertexMenu) {
                                vertexMenu.setUserData(vertex);
                                vertexMenu.show(shape, event.getScreenX(), event.getScreenY());
                            }
                        }
                    }
                }
            });
            shape.setOnMousePressed(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    dragged.set(false);
                    if (event.getButton().equals(MouseButton.PRIMARY)) {
                        // 保存当前位置
                        offsetX.set(event.getScreenX());
                        offsetY.set(event.getScreenY());
                    }
                }
            });
            shape.setOnMouseDragged(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    dragged.set(true);
                    shape.setCursor(Cursor.MOVE);
                    Circle circle = shape.getCircle();
                    // 重新设置circle位置, 会处理对应listener
                    circle.setCenterX(circle.getCenterX() + event.getScreenX() - offsetX.get());
                    circle.setCenterY(circle.getCenterY() + event.getScreenY() - offsetY.get());
                    // 保存上次位置
                    offsetX.set(event.getScreenX());
                    offsetY.set(event.getScreenY());
                }
            });

            // 动画效果
            shape.setOnMouseEntered(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    shape.setFocus();
                }
            });
            shape.setOnMouseExited(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    shape.setUnfocus();
                }
            });

                /*
                // 拖放支持
                circle.setOnDragDetected(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {
                        System.out.println("OnDragDetected()");

                        Dragboard db = circle.startDragAndDrop(TransferMode.ANY);
                        ClipboardContent clip = new ClipboardContent();
                        clip.putString("测试数据");
                        db.setContent(clip);

                        db.setDragView(circle.snapshot(null, null));

                        event.consume();
                    }
                });
                circle.setOnDragDone(new EventHandler<DragEvent>() {
                    @Override
                    public void handle(DragEvent event) {
                        System.out.println("OnDragDone()");

                        if (event.getTransferMode() == TransferMode.MOVE) {
                            //
                        }

                        event.consume();
                    }
                });
                */
            // 添加所有vertex
            //pane.getChildren().add(circle);
            pane.getChildren().add(shape);
        }

        // 遍历所有边
        graph.getEdges().stream().forEach(e -> {
            TestEdgeShape shape = ((TestEdge) e).getShape();
            shape.reset();
            shape.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    TestEdge edge = (TestEdge)shape.getUserData();
                    if (event.getButton().equals(MouseButton.PRIMARY)) {
                        System.out.println(edge.getId() + " clicked!");

                        // 回调函数
                        if (null != edgeCallback) {
                            edgeCallback.accept(e);
                        }

                        shape.switchSelected();
                    } else if (event.getButton().equals(MouseButton.SECONDARY)) {
                        shape.switchSelected();
                        // 右键菜单
                        if (null != edgeMenuCallback) {
                            ContextMenu edgeMenu = edgeMenuCallback.call(shape);
                            if (null!=edgeMenu) {
                                edgeMenu.setUserData(e);
                                edgeMenu.show(shape, event.getScreenX(), event.getScreenY());
                            }
                        }
                    }
                }
            });

            // 动画效果
            shape.setOnMouseEntered(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    shape.setFocus();
                }
            });
            shape.setOnMouseExited(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    shape.setUnfocus();
                }
            });
            // 添加所有边
            //pane.getChildren().add(((TestEdge) e).getLine());
            pane.getChildren().add(shape);
        });
    }
    public static void clearGraphView(AnchorPane pane, TestGraph graph) {
        if (null != graph) {
            graph.getEdges().stream().forEach(e -> {
                TestEdgeShape shape = ((TestEdge)e).getShape();
                shape.reset();
            });
            graph.getVertices().stream().forEach(v -> {
                TestVertexShap shape = ((TestVertex) v).getShape();
                shape.reset();
            });
        }
        pane.getChildren().clear();
    }

    public void setData(ObservableList<TestGraph> graphs) {
        this.graphs = graphs;
        graphView.setItems(graphs);
    }

    public void setDialogStage(Stage dialogStage) {
        this.dialog = dialogStage;
    }

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

    @FXML
    public void handleAddGraph(ActionEvent event) {
        TestGraph graph = new TestGraph();
        if (mainApp.showGraphCreate(dialog, graph)) {
            graphs.add(graph);
        }
    }

    @FXML
    public void handleDelGraph(ActionEvent event) {
        TestGraph graph = graphView.getSelectionModel().getSelectedItem();
        if (null != graph) {
            graphs.remove(graph);
        }
    }

    public ObservableList<TestGraph> getGraphs() {
        return graphs;
    }

    public void setGraphs(ObservableList<TestGraph> graphs) {
        this.graphs = graphs;
    }

    @FXML
    public void handleApply(ActionEvent event) {
        if (mainApp.saveGraph()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("成功");
            alert.setHeaderText("保存graph数据成功!");
            alert.showAndWait();

            dialog.close();
        }
    }
    @FXML
    public void handleCancel(ActionEvent event) {
        dialog.close();
    }
}
