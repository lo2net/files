package com.zte.sdn.oscp.algorithm.test.model;

import com.zte.sdn.oscp.algorithm.framework.graph.Vertex;
import com.zte.sdn.oscp.algorithm.test.shape.TestVertexShap;
import com.zte.sdn.oscp.algorithm.test.xml.TestVertexXmlAdapter;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

// 节点
public class TestVertex implements Vertex{
    // 标识
    private String id;

    // TODO 绘制图形
    private TestVertexShap shape = new TestVertexShap();

    private List<TestEdge> forwardEdges = new ArrayList<>();
    private List<TestEdge> backwardEdges = new ArrayList<>();

    public void init() {
        shape.init(this);
    }
    public TestVertex() {
        // TODO 这个函数是给jaxb解析xml用的,unmarshal的时候会调用
        // 根据unmarshal结果,以及circle的转换定义会重新生成新的circle成员变量
        // 所以这里的初始化实际上是初始化旧的circle对象, 而其他成员变量会由于后续主动调用init()初始化两次可能导致问题
        // 例如 group.getChildren().addAll() 就不能重复添加相同的对象(这里是text)
        //init();
    }
    public TestVertex(String id) {
        this.id = id;
        init();
    }

    @Override
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @XmlTransient
    public List<TestEdge> getForwardEdges() {
        return forwardEdges;
    }

    public void setForwardEdges(List<TestEdge> forwardEdges) {
        this.forwardEdges = forwardEdges;
    }
    @XmlTransient
    public List<TestEdge> getBackwardEdges() {
        return backwardEdges;
    }

    public void setBackwardEdges(List<TestEdge> backwardEdges) {
        this.backwardEdges = backwardEdges;
    }

    public static class Coordinate {
        private double x;
        private double y;

        public double getX() {
            return x;
        }

        public void setX(double x) {
            this.x = x;
        }

        public double getY() {
            return y;
        }

        public void setY(double y) {
            this.y = y;
        }
    }
    @XmlJavaTypeAdapter(TestVertexXmlAdapter.class)
    public TestVertexShap getShape() {
        return shape;
    }
    public void setShape(TestVertexShap shape) {
        this.shape = shape;
    }
}
