package com.zte.sdn.oscp.algorithm.test.algorithm;

import com.zte.sdn.oscp.algorithm.framework.constraints.Affinity;
import com.zte.sdn.oscp.algorithm.framework.graph.Vertex;
import com.zte.sdn.oscp.algorithm.test.model.TestGraph;
import com.zte.sdn.oscp.algorithm.test.model.TestRequest;
import com.zte.sdn.oscp.algorithm.test.model.TestSchedule;

import java.util.List;
import java.util.Random;

public class RequestGenerateWrap {
    public void generate(TestSchedule schedule, TestGraph graph, int algorithmK, boolean needOptimize, String direction,
                         String priority, String weight, String bandwidth, List<Integer> affinity, String timedelay) {
        for (int i=0; i<schedule.getCreateCounts(); ++i) {
            TestRequest request = new TestRequest();
            request.setBelongGraph(graph);
            request.setAlgKNumber(algorithmK);
            int start = (new Random()).nextInt(graph.getVertexCounts());
            int end = (new Random()).nextInt(graph.getVertexCounts());
            int k=0;
            for (Vertex vertex : graph.getVertices()) {
                if (k==start) {
                    request.setRequestStart(vertex.getId());
                }
                if (k==end) {
                    request.setRequestEnd(vertex.getId());
                }
                k++;
            }
            request.setRequestId(i + ": " + request.getRequestStart() + "-" + request.getRequestEnd());
            request.setNeedOptimize(needOptimize);

            request.setDirection(direction);
            request.setPriority(priority);
            request.setWeight(weight);
            request.setBandwidth(bandwidth);
            request.getAffinity().addAll(affinity);
            request.setTimedelay(timedelay);

            schedule.getRequests().add(request);
        }
    }
}
