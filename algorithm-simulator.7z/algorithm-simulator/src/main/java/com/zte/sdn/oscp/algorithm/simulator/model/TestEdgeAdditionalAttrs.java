package com.zte.sdn.oscp.algorithm.simulator.model;

import com.zte.sdn.oscp.algorithm.framework.graph.EdgeAdditionalAttrs;

public class TestEdgeAdditionalAttrs implements EdgeAdditionalAttrs {
    private double bwCapacity;
    private double bwUnused;
    private double bwUsed;
    private double bwUtilization;

    private double delay;
    private double load;
    private double packLossRate;
    private int priority;
    private double reliability;

    // 实现祖父类 AdditionalAttrsBase 中的接口
    @Override
    public double getDelay() {
        return delay;
    }

    @Override
    public void setDelay(double delay) {
        this.delay = delay;
    }

    @Override
    public double getLoad() {
        return load;
    }

    @Override
    public void setLoad(double load) {
        this.load = load;
    }

    @Override
    public double getPackLossRate() {
        return packLossRate;
    }

    @Override
    public void setPackLossRate(double rate) {
        packLossRate = rate;
    }

    @Override
    public int getPriority() {
        return priority;
    }

    @Override
    public void setPriority(int priorty) {
        this.priority = priorty;
    }

    @Override
    public double getReliability() {
        return reliability;
    }

    @Override
    public void setReliability(double reliability) {
        this.reliability = reliability;
    }

    @Override
    public void reset() {
        this.delay = 0;
        this.reliability = 0;
        this.load = 0;
        this.priority = 0;
        this.packLossRate = 0;
    }

    // 实现父类 EdgeAdditionalAttrs 中的接口
    @Override
    public double getBwCapacity() {
        return bwCapacity;
    }

    @Override
    public void setBwCapacity(double bwCapacity) {
        this.bwCapacity = bwCapacity;
    }

    @Override
    public double getBwUnused() {
        return bwUnused;
    }

    @Override
    public void setBwUnused(double bwUnused) {
        this.bwUnused = bwUnused;
    }

    @Override
    public double getBwUsed() {
        return bwUsed;
    }

    @Override
    public void setBwUsed(double bwUsed) {
        this.bwUsed = bwUsed;
    }

    @Override
    public double getBwUtilization() {
        return bwUtilization;
    }

    @Override
    public void setBwUtilization(double bwUtilization) {
        this.bwUtilization = bwUtilization;
    }
}
