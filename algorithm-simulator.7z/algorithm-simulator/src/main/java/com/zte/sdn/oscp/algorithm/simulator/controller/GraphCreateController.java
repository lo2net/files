package com.zte.sdn.oscp.algorithm.simulator.controller;

import com.zte.sdn.oscp.algorithm.simulator.algorithm.GraphGenerateWrap;
import com.zte.sdn.oscp.algorithm.simulator.model.TestGraph;

import java.util.HashMap;
import java.util.Map;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class GraphCreateController {

    @FXML
    TextField name;
    @FXML
    ComboBox<String> topoType;
    @FXML
    Spinner<Integer> vertexCounts;
    @FXML
    ComboBox<String> direction;
    @FXML
    Spinner<Integer> averageConnectionRatio;
    @FXML
    TextField bandWidth;
    @FXML
    TextField timeDelay;
    @FXML
    TextField weight;
    @FXML
    TextField affinity;
    @FXML
    TextField optimizeThreshold;
    @FXML
    ImageView topoTypeImgView;
    private Stage dialog;
    private boolean okClicked = false;
    private TestGraph graph;

    public TestGraph getData() {
        return graph;
    }

    public void setData(TestGraph graph) {
        this.graph = graph;
    }

    public void setDialogStage(Stage stage) {
        dialog = stage;
    }

    public boolean isOkClicked() {
        return okClicked;
    }

    @FXML
    public void handleOk() {
        // TODO
        dialog.close();
        okClicked = true;

        // TODO 当前有一个问题, 如果用户不操作修改spinner, 默认第一次没有触发更新?
        // 这里是个补救措施, 具体问题原因待查!
        graph.setVertexCounts(vertexCounts.getValue());
        graph.setAverageConnectionRatio(averageConnectionRatio.getValue());

        GraphGenerateWrap gen = new GraphGenerateWrap();
        gen.generate(graph);
    }

    @FXML
    public void handleCancel() {
        // TODO
        dialog.close();
        okClicked = false;
    }

    @FXML
    public void initialize() {
        // 初始化拓扑结构combobox
        Map<String, String> topoTypeMap = new HashMap<>();
        topoTypeMap.put("网格状拓扑结构", "/images/topo-mesh.png");
        topoTypeMap.put("环状拓扑结构", "/images/topo-circle.png");
        topoTypeMap.put("树形拓扑结构", "/images/topo-tree.png");
        topoTypeMap.put("星型", "/images/topo-star.png");
        topoTypeMap.put("总线型", "/images/topo-bus.png");
        topoTypeMap.put("随机拓扑", "/images/topo-random.png");
        topoType.getItems().addAll(topoTypeMap.keySet());

        topoType.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if (null != newValue) {
                    String imgFile = topoTypeMap.get(newValue);
                    if (null != imgFile) {
                        topoTypeImgView.setImage(new Image(imgFile));
                    }
                }
            }
        });
        vertexCounts.setValueFactory(
            new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 1000, 10));

        direction.getItems().addAll("双向", "单向");
        averageConnectionRatio.setValueFactory(
            new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10, 1));

        vertexCounts.valueProperty().addListener(new ChangeListener<Integer>() {
            @Override
            public void changed(ObservableValue<? extends Integer> observable, Integer oldValue, Integer newValue) {
                graph.setVertexCounts(newValue);
            }
        });
        averageConnectionRatio.valueProperty().addListener(new ChangeListener<Integer>() {
            @Override
            public void changed(ObservableValue<? extends Integer> observable, Integer oldValue, Integer newValue) {
                graph.setAverageConnectionRatio(newValue);
            }
        });
    }

    public void init() {
        name.textProperty().bindBidirectional(graph.nameProperty());
        topoType.valueProperty().bindBidirectional(graph.topoTypeProperty());
        direction.valueProperty().bindBidirectional(graph.directionProperty());
        bandWidth.textProperty().bindBidirectional(graph.bandWidthProperty());
        timeDelay.textProperty().bindBidirectional(graph.timeDelayProperty());
        weight.textProperty().bindBidirectional(graph.weightProperty());
        affinity.textProperty().bindBidirectional(graph.affinityProperty());
        optimizeThreshold.textProperty().bindBidirectional(graph.optimizeThresholdProperty());

        //vertexCounts.getValueFactory().valueProperty().bindBidirectional(graph.vertexCountsProperty().asObject());
        //averageConnectionRatio.getValueFactory().valueProperty().bindBidirectional(graph.averageConnectionRatioProperty().asObject());

        direction.getSelectionModel().select(0);
        // 默认选中第一个
        topoType.getSelectionModel().select(0);
        // 默认带宽1000,测试数据
        bandWidth.textProperty().setValue("1000");
        // 默认优化阈值 80%
        optimizeThreshold.textProperty().setValue("80");
        // 默认权值范围
        weight.textProperty().setValue("0");
        // 默认亲和力范围
        affinity.textProperty().setValue("0");
    }
}
