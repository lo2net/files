/**
 * Sample Skeleton for 'MainFrame.fxml' Controller Class
 */

package com.zte.sdn.oscp.algorithm.simulator.controller;

import com.zte.sdn.oscp.algorithm.simulator.MainApp;
import com.zte.sdn.oscp.algorithm.simulator.algorithm.GraphPathSearchWrap;
import com.zte.sdn.oscp.algorithm.simulator.examples.container.SurveyWizard;
import com.zte.sdn.oscp.algorithm.simulator.model.TestGraph;
import com.zte.sdn.oscp.algorithm.simulator.model.TestRequest;
import com.zte.sdn.oscp.algorithm.simulator.model.TestSchedule;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class MainFrameController {

    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    private MainApp mainApp;
    private Stage primaryStage;

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

    @FXML
    void handleAbout(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("About");
        alert.setHeaderText("OSCP algorithm testing tools");
        alert.setContentText("Framework: JavaFX\nDate: 2018/05");
        alert.showAndWait();
    }

    @FXML
    void handleClose(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void handleGraphManage(ActionEvent event) {
        mainApp.loadGraph();
        mainApp.showGraphManage();
    }

    @FXML
    void handleNewData(ActionEvent event) {
        mainApp.getAllData().clear();
        mainApp.setSchedulesFilePath(null);
        mainApp.showScheduleOverview();
    }

    @FXML
    void handleOpenData(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("XML files(*.xml)", "*.xml");
        fileChooser.getExtensionFilters().add(extFilter);
        File file = fileChooser.showOpenDialog(mainApp.getPrimaryStage());
        if (file != null) {
            // TODO 解析xml数据显示到主界面
            mainApp.showScheduleOverview();
            mainApp.loadSchedulesFromFile(file);
        }
    }

    @FXML
    void handleSaveData(ActionEvent event) {
        File personFile = mainApp.getSchedulesFilePath();
        if (personFile != null) {
            mainApp.saveSchedulesToFile(personFile);
        } else {
            handleSaveDataAs(event);
        }
    }

    @FXML
    void handleSaveDataAs(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("XML files(*.xml)", "*.xml");
        fileChooser.getExtensionFilters().add(extFilter);

        File file = fileChooser.showSaveDialog(mainApp.getPrimaryStage());
        if (file != null) {
            if (!file.getPath().endsWith(".xml")) {
                file = new File(file.getPath() + ".xml");
            }
            mainApp.saveSchedulesToFile(file);
        }
    }

    @FXML
    void handleCloseData(ActionEvent event) {
        mainApp.setSchedulesFilePath(null);
        mainApp.resetCenter();
    }

    @FXML
    void handleTest(ActionEvent event) {
        Stage stage = new Stage();
        stage.setScene(new Scene(new SurveyWizard(stage), 400, 250));
        stage.show();
    }

    @FXML
    void handleTestData(ActionEvent event) {
        // 先判断是否有数据
        if (mainApp.getAllData().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("请先创建相关测试数据!");
            alert.showAndWait();
            return;
        }

        // 先重置进度条
        for (TestSchedule schedule : mainApp.getAllData()) {
            schedule.setProgress(0.0);
        }

        // TODO 执行测试过程, 转换数据, 调用算法
        // TODO 显示进度
        Thread thread = new Thread() {
            public void run() {
                for (TestSchedule schedule : mainApp.getAllData()) {
                    // 忽略不需要执行的schedule
                    if (!schedule.isNeedExecuteSchedule()) {
                        continue;
                    }

                    double current = 0;
                    double counts = (double) schedule.getRequests().stream().filter(s -> s.getNeedExecuteRequest()).count();
                    for (TestRequest request : schedule.getRequests()) {
                        // 忽略不需要执行的request
                        if (!request.getNeedExecuteRequest()) {
                            continue;
                        }
                        GraphPathSearchWrap algorithm = new GraphPathSearchWrap();
                        TestGraph graph = mainApp.getGraph(schedule.getGraphName());
                        // TODO 调用算法
                        if (request.isRequest()) {
                            // 新建业务调用创建接口
                            if (!algorithm.pathSearch(graph, request)) {
                                return;
                            }
                        } else {
                            // 存量业务调用优化接口?
                        }

                        // TODO 模拟进度显示
                        try {
                            Thread.sleep(200);
                        } catch (Exception ex) {
                        }
                        current += 1.0;
                        schedule.setProgress(current / counts);
                    }
                    // 执行完毕
                    schedule.setProgress(1.0);
                }

                // javafx界面修改必须由Application Thread完成
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        // TODO 显示结果用户确认
                        if (mainApp.showExecute(primaryStage)) {
                            // TODO 处理确认结果，更新带宽信息等
                        }
                    }
                });
            }
        };
        thread.start();
    }

    @FXML
    void handleWizardTest(ActionEvent event) {
        boolean ok = mainApp.showWizardTest(primaryStage);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText(ok ? "顺利完成!" : "用户取消了...");
        alert.showAndWait();
    }

    @FXML
        // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }

    @FXML
    void handlePathOptimize(ActionEvent event) {
        mainApp.showPathOptimize();
    }
}

