package com.zte.sdn.oscp.algorithm.test.controller;

import com.zte.sdn.oscp.algorithm.binpacking.result.PathOptResult;
import com.zte.sdn.oscp.algorithm.test.MainApp;
import com.zte.sdn.oscp.algorithm.test.algorithm.PathOptimizeWrap;
import com.zte.sdn.oscp.algorithm.test.model.TestGraph;

import java.util.Arrays;
import java.util.List;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class PathOptimizeController {
    private Stage dialog;
    private MainApp mainApp;

    private boolean okClicked = false;

    @FXML
    ComboBox<String> graphCombo;
    @FXML
    TextField threshold;
    @FXML
    ComboBox<Integer> sceneIdCombo;
    @FXML
    ComboBox<Integer> targetIdCombo;

    @FXML
    Button runBtn;

    @FXML
    ListView<String> infoList;

    public void setDialogStage(Stage dialogStage) {
        dialog = dialogStage;
    }

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

    @FXML
    public void initialize() {
        /* 画一个三角形按钮
        Polygon triAngle = new Polygon();
        triAngle.getPoints().addAll(runBtn.getLayoutX(), runBtn.getLayoutY(),
            runBtn.getLayoutX(), runBtn.getLayoutY() + 100,
            runBtn.getLayoutX() + 100, runBtn.getLayoutY() + 50);
        runBtn.setShape(triAngle);
        runBtn.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
        runBtn.setPickOnBounds(false);
        */
        runBtn.setGraphic(new ImageView("/images/wolframalpha-32x32.png"));
    }

    public void init() {
        for (TestGraph graph : mainApp.getAllGraphData()) {
            graphCombo.getItems().add(graph.getName());
        }
        graphCombo.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if (null != newValue) {
                    TestGraph graph = mainApp.getGraph(newValue);
                    threshold.textProperty().setValue(graph.getOptimizeThreshold());
                }
            }
        });
        // 默认选中第一个
        graphCombo.getSelectionModel().select(0);

        // 场景id
        List<Integer> sceneValueList = Arrays.asList(1,2,3);
        List<String> sceneNameList = Arrays.asList("Open", "Congestion", "Global");
        sceneIdCombo.getItems().addAll(sceneValueList);
        sceneIdCombo.setConverter(new StringConverter<Integer>() {
            @Override
            public String toString(Integer object) {
                if (null != object) {
                    return sceneNameList.get(sceneValueList.indexOf(object));
                }
                return null;
            }

            @Override
            public Integer fromString(String string) {
                if (null != string) {
                    return sceneValueList.get(sceneNameList.indexOf(string));
                }
                return null;
            }
        });
        // 默认选中第一个
        sceneIdCombo.getSelectionModel().select(0);

        // 目标id
        List<Integer> targetValueList = Arrays.asList(11, 12, 13, 14, 21, 22, 23, 24, 25, 31, 32, 33, 34);
        List<String> targetNameList = Arrays.asList(
            "Min BW and hop combination",
            "Min BW and cost combination",
            "Min BW and delay combination",
            "Balanced bw utilization",
            "Min network disturbance",
            "Balanced bw utilization",
            "Balanced bw utilization and network disturbance",
            "Equal cost multipath routingg",
            "Resource acquisition",
            "Min BW and hop combination",
            "Min BW and cost combination",
            "Min BW and delay combination",
            "Balanced bw utilization"
        );
        targetIdCombo.getItems().addAll(targetValueList);
        targetIdCombo.setConverter(new StringConverter<Integer>() {
            @Override
            public String toString(Integer object) {
                if (null != object) {
                    return targetNameList.get(targetValueList.indexOf(object));
                }
                return null;
            }

            @Override
            public Integer fromString(String string) {
                if (null != string) {
                    return targetValueList.get(targetNameList.indexOf(string));
                }
                return null;
            }
        });
        // 默认选中第一个
        targetIdCombo.getSelectionModel().select(0);
    }

    public boolean isOkClicked() {
        return okClicked;
    }

    @FXML
    void handleOk(ActionEvent event) {
        okClicked = true;
        dialog.close();
    }

    @FXML
    void handleCancel(ActionEvent event) {
        okClicked = false;
        dialog.close();
    }

    @FXML
    void handleRun(ActionEvent event) {
        TestGraph graph = mainApp.getGraph(graphCombo.getValue());
        int sceneId = sceneIdCombo.getValue();
        int targetId = targetIdCombo.getValue();

        PathOptimizeWrap pathOptimize = new PathOptimizeWrap();
        PathOptResult result = pathOptimize.optimize(graph, sceneId, targetId);
        if (null != result) {
            infoList.getItems().add("执行完毕:");
            infoList.getItems().add("curGlobalBwU = " + result.getCurGlobalBwU());
        } else {
            infoList.getItems().add("执行失败!");
        }
    }
}
