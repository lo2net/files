package com.zte.sdn.oscp.algorithm.simulator.algorithm;

import com.zte.sdn.oscp.algorithm.framework.graph.Vertex;
import com.zte.sdn.oscp.algorithm.simulator.model.TestGraph;
import com.zte.sdn.oscp.algorithm.simulator.model.TestVertex;

import java.util.Random;

public class RandomGraphGenerator implements GraphGenerator {
    @Override
    public void generateGraph(TestGraph graph) {
        for (int i = 0; i < graph.getVertexCounts(); ++i) {
            graph.addVertex(new TestVertex(String.valueOf(i)));
        }
        for (int i = 0; i < graph.getAverageConnectionRatio(); ++i) {
            for (Vertex v : graph.getVertices()) {
                TestVertex vStart = (TestVertex) v;
                TestVertex vEnd = null;
                // 随机取一个
                int rnd = (new Random()).nextInt(graph.getVertexCounts());
                int k = 0;
                for (Vertex vertex : graph.getVertices()) {
                    if (k == rnd) {
                        vEnd = (TestVertex) vertex;
                        // 不能是自己
                        if (vEnd == vStart) {
                            rnd += 1;
                            continue;
                        }
                        break;
                    }
                    k++;
                }
                double min = 10;
                double max = 400;
                double startX = vStart.getShape().getCircle().getCenterX();

                if (Double.compare(startX, 0) == 0) {
                    startX = min + new Random().nextDouble() * (max - min);
                }
                double startY = vStart.getShape().getCircle().getCenterY();
                if (Double.compare(startY, 0) == 0) {
                    startY = min + new Random().nextDouble() * (max - min);
                }
                double endX = vEnd.getShape().getCircle().getCenterX();
                if (Double.compare(endX, 0) == 0) {
                    endX = min + new Random().nextDouble() * (max - min);
                }
                double endY = vEnd.getShape().getCircle().getCenterY();
                if (Double.compare(endY, 0) == 0) {
                    endY = min + new Random().nextDouble() * (max - min);
                }
                addEdge(graph, Integer.parseInt(vStart.getId()), startX, startY, Integer.parseInt(vEnd.getId()), endX, endY);
            }
        }
    }
}
