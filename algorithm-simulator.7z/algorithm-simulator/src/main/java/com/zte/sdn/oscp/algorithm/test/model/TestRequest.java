package com.zte.sdn.oscp.algorithm.test.model;

import com.zte.sdn.oscp.algorithm.framework.request.ServiceInfo;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

// 业务请求
public class TestRequest {
    // 保存所属graph
    private TestGraph belongGraph;
    private SimpleBooleanProperty needExecuteRequest = new SimpleBooleanProperty(true);
    private SimpleIntegerProperty algKNumber = new SimpleIntegerProperty(1);
    private SimpleBooleanProperty needOptimize = new SimpleBooleanProperty(false);
    private SimpleStringProperty requestId = new SimpleStringProperty("");

    // 业务az点
    private SimpleStringProperty requestStart = new SimpleStringProperty("");
    private SimpleStringProperty requestEnd = new SimpleStringProperty("");

    // 单双向
    private SimpleStringProperty direction = new SimpleStringProperty("单向");

    private SimpleStringProperty priority = new SimpleStringProperty("0");
    private SimpleStringProperty weight = new SimpleStringProperty("0");
    private SimpleStringProperty bandwidth = new SimpleStringProperty("0");
    private ObservableList<Integer> affinity = FXCollections.observableArrayList();
    private SimpleStringProperty timedelay = new SimpleStringProperty("0");

    // 未计算      - 0
    // 已计算未部署 - 1
    // 已部署      - 2
    private int status = 0;

    // ipsdn 专用?
    private ServiceInfo serverInfo;

    // 路由
    private ObservableList<TestRoute> route = FXCollections.observableArrayList();

    public boolean isRequest() {
        return status == 0;
    }
    public boolean isDeployPending() {
        return status == 1;
    }
    public void setDeployPending() {
        status = 1;
    }
    public boolean isDeployed() {
        return  status == 2;
    }
    public void setDeployed() {
        status = 2;
    }

    public String getRequestId() {
        return requestId.get();
    }

    public SimpleStringProperty requestIdProperty() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId.set(requestId);
    }

    public String getRequestStart() {
        return requestStart.get();
    }

    public SimpleStringProperty requestStartProperty() {
        return requestStart;
    }

    public void setRequestStart(String requestStart) {
        this.requestStart.set(requestStart);
    }

    public String getRequestEnd() {
        return requestEnd.get();
    }

    public SimpleStringProperty requestEndProperty() {
        return requestEnd;
    }

    public void setRequestEnd(String requestEnd) {
        this.requestEnd.set(requestEnd);
    }

    @XmlElementWrapper(name="routes")
    @XmlElement(name="route")
    public ObservableList<TestRoute> getRoute() {
        return route;
    }

    public void setRoute(ObservableList<TestRoute> route) {
        this.route = route;
    }

    public boolean isBidirection() {
        return direction.get().equals("双向");
    }

    public String getDirection() {
        return direction.get();
    }

    public SimpleStringProperty directionProperty() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction.set(direction);
    }

    public ObservableList<Integer> getAffinity() {
        return affinity;
    }

    public void setAffinity(ObservableList<Integer> affinity) {
        this.affinity = affinity;
    }

    public TestGraph getBelongGraph() {
        return belongGraph;
    }

    public void setBelongGraph(TestGraph belongGraph) {
        this.belongGraph = belongGraph;
    }

    public ServiceInfo getServerInfo() {
        return serverInfo;
    }

    public void setServerInfo(ServiceInfo serverInfo) {
        this.serverInfo = serverInfo;
    }

    // 路由约束
    public static class Constraint {
        private SimpleStringProperty masterSlave = new SimpleStringProperty("");
        private SimpleStringProperty nodeType = new SimpleStringProperty("");
        private SimpleStringProperty nodeName = new SimpleStringProperty("");
        private SimpleStringProperty type = new SimpleStringProperty(""); // FORBIDDEN禁止/MUSTPASS必经

        public Constraint() {}

        public Constraint setMaster() {
            this.masterSlave.setValue("主用");
            return this;
        }
        public Constraint setSlave() {
            this.masterSlave.setValue("备用");
            return this;
        }
        public Constraint setEdge(String nodeName) {
            this.nodeType.setValue("边");
            this.nodeName.setValue(nodeName);
            return this;
        }
        public Constraint setVertex(String nodeName) {
            this.nodeType.setValue("节点");
            this.nodeName.setValue(nodeName);
            return this;
        }
        public Constraint setMustpass() {
            this.type.setValue("必经");
            return this;
        }
        public Constraint setForbidden() {
            this.type.setValue("禁止");
            return this;
        }

        public boolean isMaster() {
            return this.masterSlave.getValue().equals("主用");
        }
        public boolean isSlave() {
            return this.masterSlave.getValue().equals("备用");
        }
        public boolean isEdge() {
            return this.nodeType.getValue().equals("边");
        }
        public boolean isVertex() {
            return this.nodeType.getValue().equals("节点");
        }
        public boolean isMustpass() {
            return this.type.getValue().equals("必经");
        }
        public boolean isForbidden() {
            return this.type.getValue().equals("禁止");
        }

        public String getMasterSlave() {
            return masterSlave.get();
        }
        public void setMasterSlave(String masterSlave) {
            this.masterSlave.set(masterSlave);
        }
        public SimpleStringProperty masterSlaveProperty() {
            return masterSlave;
        }

        public String getNodeType() {
            return nodeType.get();
        }
        public void setNodeType(String nodeType) {
            this.nodeType.set(nodeType);
        }
        public SimpleStringProperty nodeTypeProperty() {
            return nodeType;
        }

        public String getNodeName() {
            return nodeName.get();
        }
        public void setNodeName(String nodeName) {
            this.nodeName.set(nodeName);
        }
        public SimpleStringProperty nodeNameProperty() {
            return nodeName;
        }

        public String getType() {
            return type.get();
        }
        public void setType(String type) {
            this.type.set(type);
        }
        public SimpleStringProperty typeProperty() {
            return type;
        }
    };
    private ObservableList<Constraint> constraints = FXCollections.observableArrayList();

    public String getPriority() {
        return priority.get();
    }

    public SimpleStringProperty priorityProperty() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority.set(priority);
    }

    public String getWeight() {
        return weight.get();
    }

    public SimpleStringProperty weightProperty() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight.set(weight);
    }

    public String getBandwidth() {
        return bandwidth.get();
    }

    public SimpleStringProperty bandwidthProperty() {
        return bandwidth;
    }

    public void setBandwidth(String bandwidth) {
        this.bandwidth.set(bandwidth);
    }

    public String getTimedelay() {
        return timedelay.get();
    }

    public SimpleStringProperty timedelayProperty() {
        return timedelay;
    }

    public void setTimedelay(String timedelay) {
        this.timedelay.set(timedelay);
    }

    @XmlElementWrapper(name="constraints")
    @XmlElement(name="constraint")
    public ObservableList<Constraint> getConstraints() {
        return constraints;
    }

    public void setConstraints(ObservableList<Constraint> constraints) {
        this.constraints = constraints;
    }

    public Boolean getNeedExecuteRequest() {
        return needExecuteRequest.get();
    }
    public void setNeedExecuteRequest(Boolean needExecuteRequest) {
        this.needExecuteRequest.set(needExecuteRequest);
    }
    public SimpleBooleanProperty needExecuteRequestProperty() {
        return needExecuteRequest;
    }

    public Integer getAlgKNumber() {
        return algKNumber.get();
    }
    public void setAlgKNumber(Integer algKNumber) {
        this.algKNumber.set(algKNumber);
    }

    public Boolean getNeedOptimize() {
        return needOptimize.get();
    }
    public void setNeedOptimize(Boolean needOptimize) {
        this.needOptimize.set(needOptimize);
    }

    public SimpleBooleanProperty needOptimizeProperty() {
        return needOptimize;
    }

    public int getStatus() {
        return status;
    }
    public void setStatus(int status) {
        this.status = status;
    }

}
