package com.zte.sdn.oscp.algorithm.simulator.controller;

import com.zte.sdn.oscp.algorithm.simulator.model.TestGraph;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.util.converter.NumberStringConverter;

public class ScheduleCreatePageOverviewController extends WizardPageController {

    @FXML
    Label scheduleName;
    @FXML
    Label graphName;
    @FXML
    Label graphTopoType;
    @FXML
    Label createCounts;

    public ScheduleCreatePageOverviewController() {
        super("最终结果", "/images/wolframalpha.png");
    }

    public void init() {
        scheduleName.textProperty().bindBidirectional(schedule.scheduleNameProperty());
        graphName.textProperty().bindBidirectional(schedule.graphNameProperty());
        // 更新对应的topo类型
        graphName.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                TestGraph graph = mainApp.getGraph(graphName.getText());
                if (null != graph) {
                    graphTopoType.setText(graph.getTopoType());
                }
            }
        });
        createCounts.textProperty().bindBidirectional(schedule.createCountsProperty(), new NumberStringConverter());
        // 初始化
        TestGraph graph = mainApp.getGraph(graphName.getText());
        if (null != graph) {
            graphTopoType.setText(graph.getTopoType());
        }
    }

    @Override
    public void handleFinish() {
    }

    @Override
    public void handleCancel() {

    }

}

