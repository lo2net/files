package com.zte.sdn.oscp.algorithm.test;

import com.sun.javafx.tk.Toolkit;
import com.zte.sdn.oscp.algorithm.test.controller.GraphCreateController;
import com.zte.sdn.oscp.algorithm.test.controller.GraphManageController;
import com.zte.sdn.oscp.algorithm.test.controller.MainFrameController;
import com.zte.sdn.oscp.algorithm.test.controller.PathOptimizeController;
import com.zte.sdn.oscp.algorithm.test.controller.RequestCreateController;
import com.zte.sdn.oscp.algorithm.test.controller.RequestApplyController;
import com.zte.sdn.oscp.algorithm.test.controller.ScheduleInfoController;
import com.zte.sdn.oscp.algorithm.test.controller.ScheduleOverviewController;
import com.zte.sdn.oscp.algorithm.test.controller.WizardController;
import com.zte.sdn.oscp.algorithm.test.controller.WizardPageController;
import com.zte.sdn.oscp.algorithm.test.model.TestGraph;
import com.zte.sdn.oscp.algorithm.test.xml.GraphXmlWrap;
import com.zte.sdn.oscp.algorithm.test.model.TestRequest;
import com.zte.sdn.oscp.algorithm.test.model.TestRoute;
import com.zte.sdn.oscp.algorithm.test.model.TestSchedule;
import com.zte.sdn.oscp.algorithm.test.xml.ScheduleXmlWrap;

import java.io.File;
import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.SplitPane;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class MainApp extends Application {

    private Stage primaryStage;
    private BorderPane rootLayout;
    private Node oldCenter;
    private String currentFilePath = null;

    // 保存当前打开的graph
    private ObservableList<TestGraph> allGraphData = FXCollections.observableArrayList();

    public ObservableList<TestGraph> getAllGraphData() {
        return allGraphData;
    }
    // 查找指定的graph
    public TestGraph getGraph(String graphName) {
        for (TestGraph graph : allGraphData) {
            if (graph.getName().equals(graphName)) {
                return graph;
            }
        }
        return null;
    }

    // 查找指定的request
    public TestRequest getRequest(String graphName, String requestName) {
        TestGraph graph = getGraph(graphName);
        if (null!=graph) {
            for (TestRequest request : graph.getServices()) {
                if (request.getRequestId().equals(requestName)) {
                    return request;
                }
            }
        }
        return null;
    }

    public Stage getPrimaryStage() {
        return primaryStage;
    }
    public MainApp() {
     }

    public static void main(String[] args) {

        // 提供命令行接口
        if (args.length == 2) {
            String graphFileName = args[0];
            String command = args[1];

            MainApp mainApp = new MainApp();
            mainApp.loadGraphFromFile(graphFileName);

            if (command.equals("pathsearch")) {
                //
            } else if (command.equals("optimize")) {
                //
            }
            System.out.println("Command \"" + command + "\" execution successfully!\n");
            System.exit(0);
        }

        // javafx 启动
        launch(args);
    }

    @Override
    public void stop() {
    }

    @Override
    public void start(Stage primaryStage) {
        // 启动的时候, 加载所有graph数据
        loadGraph();

        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("OSCP algorithm test");

        //this.primaryStage.getIcons().add(new Image("/images/wolframalpha.png"));
        //this.primaryStage.getIcons().add(new Image("/images/wolframalpha-16x16.png"));
        this.primaryStage.getIcons().add(new Image("/images/wolframalpha-32x32.png"));

        initMainFrame();
    }

    private void initMainFrame() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/fxml/MainFrame.fxml"));
            this.rootLayout = loader.load();

            MainFrameController controller = loader.getController();
            controller.setMainApp(this);

            Scene scene = new Scene(rootLayout);
            this.primaryStage.setScene(scene);
            this.primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public TestSchedule showScheduleCreate() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/fxml/Wizard.fxml"));
            BorderPane wizard = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("创建schedule");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(wizard);
            dialogStage.setScene(scene);

            WizardController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            TestSchedule schedule = new TestSchedule();
            String pages[] = {
                "/fxml/ScheduleCreatePageBasic.fxml",
                "/fxml/ScheduleCreatePageGraph.fxml",
                "/fxml/ScheduleCreatePageRequest.fxml",
                "/fxml/ScheduleCreatePageOverview.fxml"
            };

            for (String page : pages) {
                FXMLLoader pageLoader = new FXMLLoader();
                pageLoader.setLocation(MainApp.class.getResource(page));
                controller.AddPage(pageLoader.load(), pageLoader.getController());
                WizardPageController pageController = pageLoader.getController();
                pageController.setData(schedule);
                pageController.setMainApp(this);
                pageController.init();
            }
            controller.init();

            dialogStage.showAndWait();
            if (controller.isOkClicked()) {
                return schedule;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void showGraphOverview() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/fxml/GraphManage.fxml"));
            SplitPane page = loader.load();

            this.oldCenter = this.rootLayout.getCenter();
            this.rootLayout.setCenter(page);

            GraphManageController controller = loader.getController();
            controller.setDialogStage(primaryStage);
            controller.setMainApp(this);
            controller.setData(allGraphData);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void showScheduleInfo(TestSchedule data) {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/fxml/ScheduleInfo.fxml"));
            SplitPane scheduleInfo = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("显示schedule详细信息");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(scheduleInfo);
            dialogStage.setScene(scene);

            ScheduleInfoController controller = loader.getController();
            controller.setMainApp(this);
            controller.setData(data);
            controller.setDialog(dialogStage);
            dialogStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void showGraphManage() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/fxml/GraphManage.fxml"));
            SplitPane page = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("graph管理界面");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            GraphManageController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setMainApp(this);
            controller.setData(allGraphData);
            dialogStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean showGraphCreate(Stage parent, TestGraph graph) {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/fxml/GraphCreate.fxml"));
            AnchorPane page = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Create graph");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(parent);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            GraphCreateController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setData(graph);
            controller.init();
            dialogStage.showAndWait();
            return controller.isOkClicked();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean showWizardTest(Stage parent) {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/fxml/Wizard.fxml"));
            BorderPane page = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Create graph");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(parent);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            WizardController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            {
                FXMLLoader pageLoader = new FXMLLoader();
                pageLoader.setLocation(MainApp.class.getResource("/fxml/examples/WizardPageOne.fxml"));
                controller.AddPage(pageLoader.load(), pageLoader.getController());
            }
            {
                FXMLLoader pageLoader = new FXMLLoader();
                pageLoader.setLocation(MainApp.class.getResource("/fxml/examples/WizardPageTwo.fxml"));
                controller.AddPage(pageLoader.load(), pageLoader.getController());
            }
            {
                FXMLLoader pageLoader = new FXMLLoader();
                pageLoader.setLocation(MainApp.class.getResource("/fxml/examples/WizardPageThree.fxml"));
                controller.AddPage(pageLoader.load(), pageLoader.getController());
            }
            controller.init();

            dialogStage.showAndWait();
            return controller.isOkClicked();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean showExecute(Stage parent) {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/fxml/RequestApply.fxml"));
            AnchorPane page = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("执行测试");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(parent);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            RequestApplyController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setMainApp(this);
            controller.init();
            dialogStage.showAndWait();
            return controller.isOkClicked();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean showPathOptimize() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/fxml/PathOptimize.fxml"));
            AnchorPane page = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("路径优化");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            PathOptimizeController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setMainApp(this);
            controller.init();
            dialogStage.showAndWait();
            return controller.isOkClicked();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void loadSchedulesFromFile(File file) {
        try {
            JAXBContext context = JAXBContext.newInstance(ScheduleXmlWrap.class);
            Unmarshaller um = context.createUnmarshaller();
            ScheduleXmlWrap wrapper = (ScheduleXmlWrap)um.unmarshal(file);

            allData.clear();
            allData.addAll(wrapper.getSchedules());

            // 还需要更新一下schedule中已经创建了的业务的route中的edge对应到graph中
            for (TestSchedule schedule: allData) {
                TestGraph graph = getGraph(schedule.getGraphName());
                if (null==graph) {
                    // graph已经不存在, 数据有问题, 忽略
                    break;
                }
                for (TestRequest request : schedule.getRequests()) {
                    for (TestRoute route : request.getRoute()) {
                        route.setBelongRequest(request);
                    }
                }
            }

            setGraphFilePath(file);
        } catch (Exception e) {
            if ( Toolkit.getToolkit().isFxUserThread() ) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Could not load data from file:\n" + file.getPath());
                alert.setContentText(e.getMessage());
                alert.showAndWait();
            } else {
                System.out.println("Exception: " + e.getCause());
            }
        }
    }

    public void setGraphFilePath(File file) {
        if (file != null) {
            currentFilePath = file.getPath();
            primaryStage.setTitle("当前测试数据 - " + file.getName());
        } else {
            primaryStage.setTitle("OSCP algorithm test");
        }
    }
    public File getSchedulesFilePath() {
        if (currentFilePath != null) {
            return new File(currentFilePath);
        }
        return null;
    }

    public void saveSchedulesToFile(File file) {
        try {
            JAXBContext context = JAXBContext.newInstance(ScheduleXmlWrap.class);
            Marshaller m = context.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            ScheduleXmlWrap wrapper = new ScheduleXmlWrap();
            wrapper.setSchedules(allData);
            m.marshal(wrapper, file);

            setGraphFilePath(file);
        } catch (Exception e) {
            if ( Toolkit.getToolkit().isFxUserThread() ) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Could not save data to file:\n" + file.getPath());
                alert.setContentText(e.getMessage());
                alert.showAndWait();
            } else {
                System.out.println("Exception: " + e.getMessage());
            }
        }
    }

    public boolean showRequestCreate(Stage parent, TestRequest request) {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/fxml/RequestCreate.fxml"));
            AnchorPane page = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Create graph");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(parent);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            RequestCreateController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setData(request);
            controller.init();
            dialogStage.showAndWait();
            return controller.isOkClicked();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    // 加载graph数据文件
    public void loadGraph() {
        loadGraphFromFile(defaultGraphFileName);
    }
    public void loadGraphFromFile(String graphFileName) {
        File file = new File(graphFileName);
        if (!file.exists()) {
            return;
        }
        try {
            JAXBContext context = JAXBContext.newInstance(GraphXmlWrap.class);
            Unmarshaller um = context.createUnmarshaller();
            GraphXmlWrap wrapper = (GraphXmlWrap)um.unmarshal(file);
            // TODO 特殊处理
            wrapper.initXmlUnmarshal();
            allGraphData.clear();
            allGraphData.addAll(wrapper.getGraphs());
        } catch (Exception e) {
            if ( Toolkit.getToolkit().isFxUserThread() ) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("错误");
                alert.setHeaderText("加载所有graph数据失败:\n" + file.getPath());
                alert.setContentText(e.getMessage());
                alert.showAndWait();
            } else {
                System.out.println("Exception: " + e.getMessage());
            }
        }
    }
    // 保存graph数据文件
    public boolean saveGraph() {
        return saveGraphToFile(defaultGraphFileName);
    }
    public boolean saveGraphToFile(String graphFileName) {
        File file = new File(graphFileName);
        try {
            JAXBContext context = JAXBContext.newInstance(GraphXmlWrap.class);
            Marshaller m = context.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            GraphXmlWrap wrapper = new GraphXmlWrap();
            wrapper.setGraphs(allGraphData);
            // TODO 特殊处理
            wrapper.initXmlMarshal();
            m.marshal(wrapper, file);
            return true;
        } catch (Exception e) {
            if ( Toolkit.getToolkit().isFxUserThread() ) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("错误");
                alert.setHeaderText("保存所有graph数据失败:\n" + file.getPath());
                alert.setContentText(e.getMessage());
                alert.showAndWait();
            } else {
                System.out.println("Exception: " + e.getMessage());
            }

        }
        return false;
    }

    public void resetCenter() {
        if (null != oldCenter) {
            rootLayout.setCenter(oldCenter);
        }
    }
}
