package com.zte.sdn.oscp.algorithm.simulator.xml;

import com.zte.sdn.oscp.algorithm.simulator.model.TestGraph;
import com.zte.sdn.oscp.algorithm.simulator.model.TestVertex;

import java.util.HashMap;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class TestGraphXmlVertexAdapter extends XmlAdapter<TestGraph.VertexXmlData, HashMap<String, TestVertex>> {
    @Override
    public HashMap<String, TestVertex> unmarshal(TestGraph.VertexXmlData v) {
        HashMap<String, TestVertex> vertexes = new HashMap<>();
        v.getVertexes().forEach(vertex ->
            vertexes.put(vertex.getId(), vertex)
        );
        return vertexes;
    }

    @Override
    public TestGraph.VertexXmlData marshal(HashMap<String, TestVertex> vertexes) {
        TestGraph.VertexXmlData data = new TestGraph.VertexXmlData();
        vertexes.forEach((k, v) ->
            data.getVertexes().add(v)
        );
        return data;

    }
}
