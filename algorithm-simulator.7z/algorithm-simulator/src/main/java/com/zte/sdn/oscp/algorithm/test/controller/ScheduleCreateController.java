package com.zte.sdn.oscp.algorithm.test.controller;

import com.zte.sdn.oscp.algorithm.test.MainApp;

import javafx.fxml.FXML;
import javafx.stage.Stage;

public class ScheduleCreateController {

    private MainApp mainApp;

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

    private Stage dialog;
    private boolean okClicked = false;

    public void setDialogStage(Stage stage) {
        dialog = stage;
    }

    public boolean isOkClicked() {
        return okClicked;
    }

    @FXML
    public void handleOk() {
        dialog.close();
        okClicked = true;
    }

    @FXML
    public void handleCancel() {
        dialog.close();
        okClicked = false;
    }

    @FXML
    public void handleGraphManage() {
        mainApp.showGraphManage();
    }
}
