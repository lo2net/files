package com.zte.sdn.oscp.algorithm.test.examples.controller;

import com.zte.sdn.oscp.algorithm.test.controller.WizardPageController;

public class WizardThreeController implements WizardPageControllerExam {
    @Override
    public void handleFinish() {

    }

    @Override
    public void handleCancel() {

    }

    @Override
    public String getMsg() {
        return "最后一步!";
    }
}
