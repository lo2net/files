package com.zte.sdn.oscp.algorithm.test.examples.container;

import java.util.Stack;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.layout.StackPane;

public class Wizard extends StackPane {
    private static final int UNDEFINED = -1;
    private ObservableList pages = FXCollections.observableArrayList();
    private Stack<Integer> history = new Stack<Integer>();
    private int curPageIdx = UNDEFINED;

    Wizard(WizardPage... nodes) {
        pages.addAll(nodes);
        navTo(0);
        setStyle("-fx-padding: 10; -fx-background-color: cornsilk;");
    }

    public void nextPage() {
        if (hasNextPage()) {
            navTo(curPageIdx + 1);
        }
    }

    public boolean hasNextPage() {
        return curPageIdx < (pages.size() -1) ;
    }

    public void priorPage() {
        if (hasPriorPage()) {
            navTo(history.pop(), false);
        }
    }

    public boolean hasPriorPage() {
        return !history.empty();
    }

    public void navTo(int nextPageIdx, boolean pushHistory) {
        if (nextPageIdx < 0 || nextPageIdx >= pages.size()) {
            return;
        }
        if (curPageIdx != UNDEFINED) {
            if (pushHistory) {
                history.push(curPageIdx);
            }
        }

        WizardPage nextPage = (WizardPage)pages.get(nextPageIdx);
        curPageIdx = nextPageIdx;
        getChildren().clear();
        getChildren().add(nextPage);
        nextPage.manageButtons();
    }
    private void navTo(int idx) {
        navTo(idx, true);
    }
    public void navTo(String id) {
        for(Object node : pages) {
            if (((Node)node).getId().equals(id)) {
                int nextPageIdx = pages.indexOf(node);
                if (nextPageIdx != UNDEFINED) {
                    navTo(nextPageIdx);
                    return;
                }
            }
        }

        Node page = lookup("#" + id);
        if (null != page) {
            int nextPageIdx = pages.indexOf(page);
            if (nextPageIdx != UNDEFINED) {
                navTo(nextPageIdx);
            }
        }
    }

    public void cancel() {

    }

    public void finish() {

    }
}
