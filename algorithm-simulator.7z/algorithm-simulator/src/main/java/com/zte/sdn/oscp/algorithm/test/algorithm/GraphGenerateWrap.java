package com.zte.sdn.oscp.algorithm.test.algorithm;

import com.zte.sdn.oscp.algorithm.test.model.TestGraph;

public class GraphGenerateWrap {

    public void generate(TestGraph graph) {
        // TODO 根据graph选择的属性, 生成完整的数据
        GraphGenerator gen = null;
        switch(graph.getTopoType()) {
            case "网格状拓扑结构":
                gen = new MeshGraphGenerator();
                break;
            case "环状拓扑结构":
                gen = new CircleGraphGenerator();
                break;
            case "树形拓扑结构":
                gen = new TreeGraphGenerator();
                break;
            case "星型":
                gen = new StarGraphGenerator();
                break;
            case "总线型":
                gen = new BusGraphGenerator();
                break;
            case "随机拓扑":
                gen = new RandomGraphGenerator();
                break;
            default:
                break;
        }
        if (null != gen) {
            gen.generateGraph(graph);
        }
    }
}
