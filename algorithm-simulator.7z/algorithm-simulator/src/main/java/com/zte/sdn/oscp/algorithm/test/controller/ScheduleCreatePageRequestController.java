package com.zte.sdn.oscp.algorithm.test.controller;

import com.zte.sdn.oscp.algorithm.test.algorithm.RequestGenerateWrap;

import java.util.ArrayList;
import java.util.List;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.util.StringConverter;

public class ScheduleCreatePageRequestController extends WizardPageController {

    @FXML
    Spinner<Integer> counts;
    @FXML
    Spinner<Integer> algorithmK;
    @FXML
    ToggleGroup createTypeGroup;
    @FXML
    ComboBox<String> direction;
    @FXML
    TextField priority;
    @FXML
    TextField weight;
    @FXML
    TextField bandwidth;

    @FXML
    CheckBox includeAllCheckbox;
    @FXML
    TextField includeAll;
    @FXML
    CheckBox includeAnyCheckbox;
    @FXML
    TextField includeAny;
    @FXML
    CheckBox excludeAnyCheckbox;
    @FXML
    TextField excludeAny;

    @FXML
    TextField timedelay;
    @FXML
    ComboBox<Boolean> needOptimize;

    public ScheduleCreatePageRequestController() {
        super("创建业务相关", "/images/wolframalpha.png");
    }

    @FXML
    public void initialize() {
        counts.setValueFactory(
            new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 100, 10));

        algorithmK.setValueFactory(
            new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10, 1));

        needOptimize.getItems().addAll(false, true);
        needOptimize.setConverter(new StringConverter<Boolean>() {
            @Override
            public String toString(Boolean object) {
                return ((null!=object) && object) ? "是" : "否";
            }

            @Override
            public Boolean fromString(String string) {
                return string.equals("是");
            }
        });

        direction.getItems().addAll("双向", "单向");

        createTypeGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
            @Override
            public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) {
                RadioButton btn = (RadioButton)newValue;
                if (null!=btn) {
                    algorithmK.setDisable(btn.getId().equals("#algorithmKRadio"));
                }
            }
        });

        includeAllCheckbox.selectedProperty().addListener(
            (observable, oldValue, newValue) -> {
                if (null != newValue) {
                    includeAll.setDisable(!newValue);
                }
            });
        includeAll.textProperty().setValue("0");
        includeAll.setDisable(true);
        includeAnyCheckbox.selectedProperty().addListener(
            (observable, oldValue, newValue) -> {
                if (null != newValue) {
                    includeAny.setDisable(!newValue);
                }
            });
        includeAny.textProperty().setValue("0");
        includeAny.setDisable(true);
        excludeAnyCheckbox.selectedProperty().addListener(
            (observable, oldValue, newValue) -> {
                if (null != newValue) {
                    excludeAny.setDisable(!newValue);
                }
            });
        excludeAny.textProperty().setValue("0");
        excludeAny.setDisable(true);
    }

    public void init() {
        // 绑定 spinner 数据
        // TODO 这样绑定之后,就不能直接设置schedule中的setCreateCounts()了...
        //schedule.createCountsProperty().bind(counts.valueProperty());
        counts.valueProperty().addListener(new ChangeListener<Integer>() {
            @Override
            public void changed(ObservableValue<? extends Integer> observable, Integer oldValue, Integer newValue) {
                schedule.setCreateCounts(newValue);
            }
        });
        // TODO spinner默认值手工设置一下, 现在还没找到好办法处理spinner绑定相关的问题...
        schedule.setCreateCounts(10);

        needOptimize.getSelectionModel().select(0);
        direction.getSelectionModel().select(0);

        // 默认带宽, 测试数据10
        bandwidth.textProperty().setValue("10");
    }

    @Override
    public void handleFinish() {
        // TODO 根据用户选择的构造方式构造测试数据, 目前示例只有随机, 后续还要考虑各种不同的构造方式
        schedule.setCreateCounts(counts.getValue());

        // 如果选择了主备方式
        int type = algorithmK.getValue();
        RadioButton btn = (RadioButton)createTypeGroup.getSelectedToggle();
        if (btn.getId().equals("trySeparateRadio")) {
            type = -1;
        } else if (btn.getId().equals("fullSeparateRadio")) {
            type = -2;
        }

        // 亲和力
        List<Integer> affinity = new ArrayList<>();
        affinity.add(includeAllCheckbox.isSelected() ? Integer.valueOf(includeAll.textProperty().getValue()) : 0);
        affinity.add(includeAnyCheckbox.isSelected() ? Integer.valueOf(includeAny.textProperty().getValue()) : 0);
        affinity.add(excludeAnyCheckbox.isSelected() ? Integer.valueOf(excludeAny.textProperty().getValue()) : 0);

        RequestGenerateWrap gen = new RequestGenerateWrap();
        gen.generate(schedule, mainApp.getGraph(schedule.getGraphName()), type, needOptimize.getValue(), direction.getValue(),
            priority.getText(), weight.getText(), bandwidth.getText(), affinity, timedelay.getText());
    }

    @Override
    public void handleCancel() {

    }
}
