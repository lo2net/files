package com.zte.sdn.oscp.algorithm.simulator.shape;

import com.zte.sdn.oscp.algorithm.simulator.model.TestEdge;

import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.text.Text;
import javafx.scene.text.TextBoundsType;

public class TestEdgeShape extends Group {
    private Line line = new Line();
    private Polygon polygon = new Polygon();
    private Text text = new Text();

    // TODO 保存一下上一次操作的节点的部分状态?
    private Paint previous = null;

    // 路由计算结果确认后,需要更新一些显示信息
    public void updateInfo() {
        // TODO 先显示剩余带宽吧
        TestEdge edge = (TestEdge) getUserData();
        text.setText(String.valueOf(edge.getEdgeAdditionalAttrs().getBwUnused()));
    }

    public void init(TestEdge edge) {
        // 避免重复初始化
        if (null != getUserData()) {
            return;
        }
        setUserData(edge);

        // 设置需要显示的内容
        updateInfo();

        // 为了拖动circle, 不响应鼠标, 这样的话event直接到circle
        text.setMouseTransparent(true);
        text.setBoundsType(TextBoundsType.VISUAL);

        // 初始化位置
        reposition(line.getStartX(), line.getStartY(), line.getEndX(), line.getEndY(), false);

        line.startXProperty().addListener((obj, o, newValue) ->
            reposition(newValue.doubleValue(), line.getStartY(), line.getEndX(), line.getEndY(), false));
        line.startYProperty().addListener((obj, o, newValue) ->
            reposition(line.getStartX(), newValue.doubleValue(), line.getEndX(), line.getEndY(), false));
        line.endXProperty().addListener((obj, o, newValue) ->
            reposition(line.getStartX(), line.getStartY(), newValue.doubleValue(), line.getEndY(), false));
        line.endYProperty().addListener((obj, o, newValue) ->
            reposition(line.getStartX(), line.getStartY(), line.getEndX(), newValue.doubleValue(), false));

        getChildren().addAll(line, polygon, text);
    }

    public void reposition(double startX, double startY, double endX, double endY, boolean increase) {

        // 定义箭头斜边大小以及角度
        double sLen = Math.sqrt(Math.pow(startX - endX, 2) + Math.pow(startY - endY, 2)) / 4;
        if (sLen > 16) {
            sLen = 16;
        }
        if (increase) {
            sLen += 2;
        }
        double arc = Math.atan(1) / 2; // 角度

        polygon.getPoints().clear();
        /*
        坐标系:
                X
        (0,0)--------->
          |
        Y |
          |
          V

        绘制箭头如下形状, text放到跟箭头同一侧位置
        添加点顺序 1 - 2 -3
        1
        |\
        | \
   vLen |  \ sLen
        |   \
        2----3
        | hLen
        |
        |
        |
        */
        //double sLen = 16.0; // 斜边
        //double arc = Math.atan(1)/2; // 角度
        double vLen = sLen * Math.cos(arc); // 直角边
        double hLen = sLen * Math.sin(arc); // 直角边
        /* text坐标是左下角(x,y), 默认情况下rotate是绕中心点顺时针开始
        text显示需要旋转到和边的角度一致, 并且垂直距离为gap的位置
        计算方法是先找到目标位置中心点, 然后就可以直接找到左下角坐标
                |-----------|
                |           |
                |-----------|
                      |
                      | gap
                      |
        -----------------------------
         */
        double gap = 3; // text最下沿和边之间的垂直距离

        double textHalfHeight = text.getBoundsInLocal().getHeight() / 2;
        double textHalfWidth = text.getBoundsInLocal().getWidth() / 2;
        double len = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2)) / 2;
        // 如果边太短就不显示text
        text.setVisible(len > (textHalfWidth + 20));

        /*
                  end
        箭头侧 ---> \
                    \
               text \
                     \
                      \
                    start
        */
        if ((startX >= endX) && (startY > endY)) {
            if (Double.compare(startX, endX) == 0) {
                polygon.getPoints().addAll(endX, endY,
                    endX, endY + vLen,
                    endX - hLen, endY + vLen);
                text.setX(startX - gap - textHalfHeight - textHalfWidth);
                text.setY(startY - (startY - endY) / 2 + textHalfHeight);
                text.setRotate(90);
            } else {
                double lineArc = Math.atan((startX - endX) / (startY - endY));
                polygon.getPoints().addAll(endX, endY,
                    endX + vLen * Math.sin(lineArc), endY + vLen * Math.cos(lineArc),
                    endX + sLen * Math.sin(lineArc - arc), endY + sLen * Math.cos(lineArc - arc));
                text.setX(startX - len * Math.sin(lineArc) - (gap + textHalfHeight) * Math.cos(lineArc) - textHalfWidth);
                text.setY(startY - len * Math.cos(lineArc) + (gap + textHalfHeight) * Math.sin(lineArc) + textHalfHeight);
                text.setRotate(90 - lineArc * 180 / Math.PI);
            }
        }
        /*
                   end
        箭头侧---> /
                 /
           text /
               /
              /
           start
        */
        if ((startX < endX) && (startY >= endY)) {
            if (Double.compare(startY ,endY) == 0) {
                polygon.getPoints().addAll(endX, endY,
                    endX - vLen, endY,
                    endX - vLen, endY - hLen);
                text.setX(startX + (endX - startX) / 2 - textHalfWidth);
                text.setY(startY - gap);
                text.setRotate(0);
            } else {
                double lineArc = Math.atan((endX - startX) / (startY - endY));
                polygon.getPoints().addAll(endX, endY,
                    endX - vLen * Math.sin(lineArc), endY + vLen * Math.cos(lineArc),
                    endX - sLen * Math.sin(lineArc + arc), endY + sLen * Math.cos(lineArc + arc));
                text.setX(startX + len * Math.sin(lineArc) - (gap + textHalfHeight) * Math.cos(lineArc) - textHalfWidth);
                text.setY(startY - len * Math.cos(lineArc) - (gap + textHalfHeight) * Math.sin(lineArc) + textHalfHeight);
                text.setRotate(270 + lineArc * 180 / Math.PI);
            }
        }
        /*
             start
               \
                \
                 \ text
                  \
                   \ <--- 箭头侧
                  end
        */
        if ((startX <= endX) && (startY < endY)) {
            if (Double.compare(startX, endX) == 0) {
                polygon.getPoints().addAll(endX, endY,
                    endX, endY - vLen,
                    endX + hLen, endY - vLen);
                text.setX(startX + gap + textHalfHeight - textHalfWidth);
                text.setY(startY + (endY - startY) / 2 + textHalfHeight);
                text.setRotate(90);
            } else {
                double lineArc = Math.atan((endX - startX) / (endY - startY));
                polygon.getPoints().addAll(endX, endY,
                    endX - vLen * Math.sin(lineArc), endY - vLen * Math.cos(lineArc),
                    endX - sLen * Math.sin(lineArc - arc), endY - sLen * Math.cos(lineArc - arc));
                text.setX(startX + len * Math.sin(lineArc) + (gap + textHalfHeight) * Math.cos(lineArc) - textHalfWidth);
                text.setY(startY + len * Math.cos(lineArc) - (gap + textHalfHeight) * Math.sin(lineArc) + textHalfHeight);
                text.setRotate(90 - lineArc * 180 / Math.PI);
            }
        }
        /*
            start
             /
            /
           /
          / <---箭头侧
        end
        */
        if ((startX > endX) && (startY <= endY)) {
            if (Double.compare(startY ,endY) == 0) {
                polygon.getPoints().addAll(endX, endY,
                    endX + vLen, endY,
                    endX + vLen, endY + hLen);
                text.setX(startX - (startX - endX) / 2 - textHalfWidth);
                text.setY(startY + gap + textHalfHeight * 2);
                text.setRotate(0);
            } else {
                double lineArc = Math.atan((startX - endX) / (endY - startY));
                polygon.getPoints().addAll(endX, endY,
                    endX + vLen * Math.sin(lineArc), endY - vLen * Math.cos(lineArc),
                    endX + sLen * Math.sin(lineArc + arc), endY - sLen * Math.cos(lineArc + arc));
                text.setX(startX - len * Math.sin(lineArc) + (gap + textHalfHeight) * Math.cos(lineArc) - textHalfWidth);
                text.setY(startY + len * Math.cos(lineArc) + (gap + textHalfHeight) * Math.sin(lineArc) + textHalfHeight);
                text.setRotate(270 + lineArc * 180 / Math.PI);
            }
        }
    }

    // 计算line位置
    public void calcLinePosition() {
        Line line = getLine();
        Circle start = ((TestEdge) getUserData()).getSrc().getShape().getCircle();
        Circle end = ((TestEdge) getUserData()).getDst().getShape().getCircle();
        double startX = start.getCenterX();
        double startY = start.getCenterY();
        double endX = end.getCenterX();
        double endY = end.getCenterY();
        double startRadius = start.getRadius() + 2; // padding, 避免画得太紧
        double endRadius = end.getRadius() + 2; // padding, 避免画得太紧

        // 校验数据
        if ((Double.compare(startX ,endX) == 0) && (Double.compare(startY, endY) == 0)) {
            return;
        }

        TestEdge reverseEdge = ((TestEdge) getUserData()).getReverse();
        // 如果是单向边, 就直接在两个circle圆心连接线上绘制一条边
        if (null == reverseEdge) {
            double offXLineStart = (startRadius * (endX - startX)) / Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
            double offYLineStart = (startRadius * (endY - startY)) / Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
            line.setStartX(startX + offXLineStart);
            line.setStartY(startY + offYLineStart);

            double offXLineEnd = (endRadius * (endX - startX)) / Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
            double offYLineEnd = (endRadius * (endY - startY)) / Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
            line.setEndX(endX - offXLineEnd);
            line.setEndY(endY - offYLineEnd);
        } else { // 双向边, 则需要考虑两条边的相对位置
            double gap = 3;
            Line reverseLine = ((TestEdge) getUserData()).getReverse().getShape().getLine();

            if ((startX >= endX) && (startY > endY)) {
                if (Double.compare(startX ,endX) == 0) {
                    double offsetY = Math.sqrt(Math.pow(startRadius, 2) - Math.pow(gap, 2));
                    line.setStartX(startX - gap);
                    line.setStartY(startY - offsetY);
                    offsetY = Math.sqrt(Math.pow(endRadius, 2) - Math.pow(gap, 2));
                    line.setEndX(endX - gap);
                    line.setEndY(endY + offsetY);
                } else {
                    double arc = Math.atan((startY - endY) / (startX - endX)) - Math.asin(gap / startRadius);
                    line.setStartX(startX - Math.cos(arc) * startRadius);
                    line.setStartY(startY - Math.sin(arc) * startRadius);
                    arc = Math.atan((startX - endX) / (startY - endY)) - Math.asin(gap / endRadius);
                    line.setEndX(endX + Math.sin(arc) * endRadius);
                    line.setEndY(endY + Math.cos(arc) * endRadius);
                }
            }
            if ((startX < endX) && (startY >= endY)) {
                if (Double.compare(startY, endY) == 0) {
                    double offsetX = Math.sqrt(Math.pow(startRadius, 2) - Math.pow(gap, 2));
                    line.setStartX(startX + offsetX);
                    line.setStartY(startY - gap);
                    offsetX = Math.sqrt(Math.pow(endRadius, 2) - Math.pow(gap, 2));
                    line.setEndX(endX - offsetX);
                    line.setEndY(endY - gap);
                } else {
                    double arc = Math.atan((endX - startX) / (startY - endY)) - Math.asin(gap / startRadius);
                    line.setStartX(startX + Math.sin(arc) * startRadius);
                    line.setStartY(startY - Math.cos(arc) * startRadius);
                    arc = Math.atan((startY - endY) / (endX - startX)) - Math.asin(gap / endRadius);
                    line.setEndX(endX - Math.cos(arc) * endRadius);
                    line.setEndY(endY + Math.sin(arc) * endRadius);
                }
            }
            if ((startX <= endX) && (startY < endY)) {
                if (Double.compare(startX, endX) == 0) {
                    double offsetY = Math.sqrt(Math.pow(startRadius, 2) - Math.pow(gap, 2));
                    line.setStartX(startX + gap);
                    line.setStartY(startY + offsetY);
                    offsetY = Math.sqrt(Math.pow(endRadius, 2) - Math.pow(gap, 2));
                    line.setEndX(endX + gap);
                    line.setEndY(endY - offsetY);
                } else {
                    double arc = Math.atan((endX - startX) / (endY - startY)) + Math.asin(gap / startRadius);
                    line.setStartX(startX + Math.sin(arc) * startRadius);
                    line.setStartY(startY + Math.cos(arc) * startRadius);
                    arc = Math.atan((endX - startX) / (endY - startY)) - Math.asin(gap / endRadius);
                    line.setEndX(endX - Math.sin(arc) * endRadius);
                    line.setEndY(endY - Math.cos(arc) * endRadius);
                }
            }
            if ((startX > endX) && (startY <= endY)) {
                if (Double.compare(startY, endY) == 0) {
                    double offsetX = Math.sqrt(Math.pow(startRadius, 2) - Math.pow(gap, 2));
                    line.setStartX(startX - offsetX);
                    line.setStartY(startY + gap);
                    offsetX = Math.sqrt(Math.pow(endRadius, 2) - Math.pow(gap, 2));
                    line.setEndX(endX + offsetX);
                    line.setEndY(endY + gap);
                } else {
                    double arc = Math.atan((endY - startY) / (startX - endX)) + Math.asin(gap / startRadius);
                    line.setStartX(startX - Math.cos(arc) * startRadius);
                    line.setStartY(startY + Math.sin(arc) * startRadius);
                    arc = Math.atan((startX - endX) / (endY - startY)) + Math.asin(gap / endRadius);
                    line.setEndX(endX + Math.sin(arc) * endRadius);
                    line.setEndY(endY - Math.cos(arc) * endRadius);
                }
            }
        }
    }

    // 恢复line默认状态
    public void reset() {
        line.setStroke(Color.BLACK);
        line.setStrokeWidth(2.0);
        line.setStrokeLineCap(StrokeLineCap.ROUND);
        line.setCursor(Cursor.HAND);

        polygon.setFill(Color.BLACK);

        text.setFill(Color.BLACK);
    }

    // 高亮line
    public void setHighlight() {
        line.setStroke(Color.CYAN);

        polygon.setFill(Color.CYAN);
    }

    // 选中/不选中line
    public void switchSelected() {
        if (isSelected()) {
            setUnselected();
        } else {
            setSelected();
        }
    }

    public void setSelected() {
        previous = line.getStroke();
        line.setStroke(Color.YELLOW);

        polygon.setFill(Color.YELLOW);
        text.setFill(Color.YELLOW);
    }

    public void setUnselected() {
        line.setStroke(previous);
        polygon.setFill(previous);
        text.setFill(previous);
    }

    public boolean isSelected() {
        return line.getStroke().equals(Color.YELLOW);
    }

    public void setFocus() {
        line.setStrokeWidth(line.getStrokeWidth() + 1);
        //polygon.setStrokeWidth(polygon.getStrokeWidth() + 1);
        reposition(line.getStartX(), line.getStartY(), line.getEndX(), line.getEndY(), true);
    }

    public void setUnfocus() {
        line.setStrokeWidth(line.getStrokeWidth() - 1);
        //polygon.setStrokeWidth(polygon.getStrokeWidth() - 1);
        reposition(line.getStartX(), line.getStartY(), line.getEndX(), line.getEndY(), true);
    }

    public Line getLine() {
        return line;
    }

    public Text getText() {
        return text;
    }

    public void setForbidden() {
        line.setStroke(Color.RED);
        polygon.setFill(Color.RED);
        text.setFill(Color.RED);
    }

    public void setMustpass() {
        line.setStroke(Color.GREEN);
        polygon.setFill(Color.GREEN);
        text.setFill(Color.GREEN);
    }
}
