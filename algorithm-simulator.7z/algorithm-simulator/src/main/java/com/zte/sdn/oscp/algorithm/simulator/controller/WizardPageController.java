package com.zte.sdn.oscp.algorithm.simulator.controller;

import com.zte.sdn.oscp.algorithm.simulator.MainApp;
import com.zte.sdn.oscp.algorithm.simulator.model.TestSchedule;

import javafx.scene.image.Image;

public class WizardPageController {

    protected MainApp mainApp;
    protected TestSchedule schedule;
    private String msg;
    private Image icon;

    WizardPageController(String msg, String icon) {
        this.msg = msg;
        this.icon = new Image(icon);
    }

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

    public void setData(TestSchedule schedule) {
        this.schedule = schedule;
    }

    public void handleFinish() {
    }

    public void handleCancel() {
    }

    public void init() {
    }

    public String getMsg() {
        return msg;
    }

    public Image getIcon() {
        return icon;
    }
}
