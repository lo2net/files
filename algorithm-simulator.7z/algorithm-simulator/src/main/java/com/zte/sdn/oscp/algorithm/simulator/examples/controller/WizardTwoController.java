package com.zte.sdn.oscp.algorithm.simulator.examples.controller;

public class WizardTwoController implements WizardPageControllerExam {
    @Override
    public void handleFinish() {

    }

    @Override
    public void handleCancel() {

    }

    @Override
    public String getMsg() {
        return "来到了第二步...";
    }
}
