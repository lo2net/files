package com.zte.sdn.oscp.algorithm.test.model;

import com.zte.sdn.oscp.algorithm.framework.graph.Edge;
import com.zte.sdn.oscp.algorithm.test.shape.TestEdgeShape;
import com.zte.sdn.oscp.algorithm.test.xml.TestEdgeXmlAdapter;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import javafx.beans.InvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableObjectValue;

// 拓扑链路
public class TestEdge implements Edge{
    // 标识
    private String id;
    private TestVertex src = new TestVertex();
    private TestVertex dst = new TestVertex();
    // 权值
    private double weight;
    // 共享风险组id(SRLG/SRNG)
    private String srgId;

    private TestEdgeAdditionalAttrs edgeAdditionalAttrs = new TestEdgeAdditionalAttrs();

    // 绘制图形
    private TestEdgeShape shape = new TestEdgeShape();

    // 反向edge, 不保存
    private TestEdge reverse = null;

    // 更新信息
    public void updateInfo() {
        shape.updateInfo();
    }
    public void init() {
        shape.init(this);
    }

    @Override
    public String getId() {
        return id;
    }
    @Override
    // az点
    @XmlElement(name="src")
    public TestVertex getSrc() {
        return src;
    }
    public void setSrc(TestVertex src) {
        this.src = src;
    }
    @Override
    @XmlElement(name="dst")
    public TestVertex getDst() {
        return dst;
    }
    public void setDst(TestVertex dst) {
        this.dst = dst;
    }
    @Override
    @XmlElement(name="attrs")
    public TestEdgeAdditionalAttrs getEdgeAdditionalAttrs() {
        return edgeAdditionalAttrs;
    }
    public void setEdgeAdditionalAttrs(TestEdgeAdditionalAttrs edgeAdditionalAttrs) {
        this.edgeAdditionalAttrs = edgeAdditionalAttrs;
    }
    @Override
    public double getWeight() {
        return weight;
    }
    @Override
    public void setWeight(double weight) {
        this.weight = weight;
    }

    // jaxb需要默认的构造函数
    public TestEdge() {
        // TODO 为啥不能调用请参考 TestVertex 中的说明
        //init();
    }
    public TestEdge(String id, TestVertex src, TestVertex dst) {
        this.id = id;
        this.src = src;
        this.dst = dst;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "id=" + ((null==id)?"null":id) + ", A=" + ((null==src)?"null":src.getId()) + ", Z=" + ((null==dst)?"null":dst.getId());
    }

    public String getSrgId() {
        return srgId;
    }

    public void setSrgId(String srgId) {
        this.srgId = srgId;
    }

    @XmlTransient
    public TestEdge getReverse() {
        return reverse;
    }

    public void setReverse(TestEdge reverse) {
        this.reverse = reverse;
    }

    public static class LineData {
        private TestVertex.Coordinate start;
        private TestVertex.Coordinate end;

        public TestVertex.Coordinate getStart() {
            return start;
        }

        public void setStart(TestVertex.Coordinate start) {
            this.start = start;
        }

        public TestVertex.Coordinate getEnd() {
            return end;
        }

        public void setEnd(TestVertex.Coordinate end) {
            this.end = end;
        }
    }
    @XmlJavaTypeAdapter(TestEdgeXmlAdapter.class)
    public TestEdgeShape getShape() {
        return shape;
    }
    public void setShape(TestEdgeShape shape) {
        this.shape = shape;
    }
}
