package com.zte.sdn.oscp.algorithm.test.controller;

import com.zte.sdn.oscp.algorithm.test.model.TestRequest;

import java.util.ArrayList;
import java.util.List;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class RequestCreateController {
    private Stage dialog;
    private boolean okClicked = false;
    private TestRequest request;

    @FXML
    private TextField requestId;
    @FXML
    private TextField requestStart;
    @FXML
    private TextField requestEnd;
    @FXML
    private Spinner<Integer> algorithmK;
    @FXML
    ToggleGroup createTypeGroup;
    @FXML
    private ComboBox<String> direction;
    @FXML
    private TextField priority;
    @FXML
    private TextField weight;
    @FXML
    private TextField bandwidth;

    @FXML
    CheckBox includeAllCheckbox;
    @FXML
    TextField includeAll;
    @FXML
    CheckBox includeAnyCheckbox;
    @FXML
    TextField includeAny;
    @FXML
    CheckBox excludeAnyCheckbox;
    @FXML
    TextField excludeAny;

    @FXML
    private TextField timedelay;
    @FXML
    private ComboBox<Boolean> needOptimize;

    public void setData(TestRequest request) {
        this.request = request;
    }
    public TestRequest getRequest() {
        return this.request;
    }

    public void setDialogStage(Stage dialog) {
        this.dialog = dialog;
    }

    @FXML
    public void initialize() {
        algorithmK.setValueFactory(
            new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10, 1));
        needOptimize.getItems().addAll(true, false);
        needOptimize.setConverter(new StringConverter<Boolean>() {
            @Override
            public String toString(Boolean object) {
                return ((null!=object) && object) ? "是" : "否";
            }

            @Override
            public Boolean fromString(String string) {
                return string.equals("是");
            }
        });
        direction.getItems().addAll("双向", "单向");

        createTypeGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
            @Override
            public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) {
                RadioButton btn = (RadioButton)newValue;
                if (null!=btn) {
                    algorithmK.setDisable(btn.getId().equals("#algorithmKRadio"));
                }
            }
        });

        includeAllCheckbox.selectedProperty().addListener(
            (observable, oldValue, newValue) -> {
                if (null != newValue) {
                    includeAll.setDisable(!newValue);
                }
            });
        includeAll.textProperty().setValue("0");
        includeAll.setDisable(true);
        includeAnyCheckbox.selectedProperty().addListener(
            (observable, oldValue, newValue) -> {
                if (null != newValue) {
                    includeAny.setDisable(!newValue);
                }
            });
        includeAny.textProperty().setValue("0");
        includeAny.setDisable(true);
        excludeAnyCheckbox.selectedProperty().addListener(
            (observable, oldValue, newValue) -> {
                if (null != newValue) {
                    excludeAny.setDisable(!newValue);
                }
            });
        excludeAny.textProperty().setValue("0");
        excludeAny.setDisable(true);
    }
    public void init() {
        requestId.textProperty().bindBidirectional(request.requestIdProperty());
        requestStart.textProperty().bindBidirectional(request.requestStartProperty());
        requestEnd.textProperty().bindBidirectional(request.requestEndProperty());
        algorithmK.valueProperty().addListener(new ChangeListener<Integer>() {
            @Override
            public void changed(ObservableValue<? extends Integer> observable, Integer oldValue, Integer newValue) {
                request.setAlgKNumber(newValue);
            }
        });
        direction.valueProperty().bindBidirectional(request.directionProperty());
        priority.textProperty().bindBidirectional(request.priorityProperty());
        weight.textProperty().bindBidirectional(request.weightProperty());
        bandwidth.textProperty().bindBidirectional(request.bandwidthProperty());
        timedelay.textProperty().bindBidirectional(request.timedelayProperty());
        needOptimize.valueProperty().bindBidirectional(request.needOptimizeProperty());

        // 默认带宽
        bandwidth.textProperty().setValue("10");
    }

    public boolean isOkClicked() {
        return okClicked;
    }

    @FXML
    public void handleOk() {
        dialog.close();
        okClicked = true;

        // 如果选择了主备方式
        int type = algorithmK.getValue();
        RadioButton btn = (RadioButton)createTypeGroup.getSelectedToggle();
        if (btn.getId().equals("trySeparateRadio")) {
            type = -1;
        } else if (btn.getId().equals("fullSeparateRadio")) {
            type = -2;
        }
        request.setAlgKNumber(type);

        // 亲和力
        List<Integer> affinity = new ArrayList<>();
        affinity.add(includeAllCheckbox.isSelected() ? Integer.valueOf(includeAll.textProperty().getValue()) : 0);
        affinity.add(includeAnyCheckbox.isSelected() ? Integer.valueOf(includeAny.textProperty().getValue()) : 0);
        affinity.add(excludeAnyCheckbox.isSelected() ? Integer.valueOf(excludeAny.textProperty().getValue()) : 0);
        request.getAffinity().addAll(affinity);
    }

    @FXML
    public void handleCancel() {
        dialog.close();
        okClicked = false;
    }
}
