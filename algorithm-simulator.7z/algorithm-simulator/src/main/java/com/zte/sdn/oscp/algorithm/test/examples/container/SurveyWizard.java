package com.zte.sdn.oscp.algorithm.test.examples.container;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

class SurveyData {
    BooleanProperty hasComplaints = new SimpleBooleanProperty();
    StringProperty complaints = new SimpleStringProperty();
    static SurveyData instance = new SurveyData();
}

class ComplaintsPage extends WizardPage {
    private RadioButton yes;
    private RadioButton no;
    private ToggleGroup options = new ToggleGroup();

    public ComplaintsPage() {
        super("Complaints");

        nextButton.setDisable(true);
        finishButton.setDisable(true);
        yes.setToggleGroup(options);
        no.setToggleGroup(options);

        options.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
            @Override
            public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) {
                nextButton.setDisable(false);
                finishButton.setDisable(false);
            }
        });

    }

    @Override
    public Parent getContent() {
        yes = new RadioButton("Yes");
        no = new RadioButton("No");
        SurveyData.instance.hasComplaints.bind(yes.selectedProperty());
        VBox box = new VBox();
        box.setSpacing(5);
        box.getChildren().addAll(new Label("Do you have complaints?"), yes, no);
        return box;
    }

    @Override
    public void nextPage() {
        if (options.getSelectedToggle().equals(yes)) {
            super.nextPage();
        } else {
            navTo("Thanks");
        }
    }
}

class MoreInformationPage extends WizardPage {
    public MoreInformationPage() {
        super("More Info");
    }

    @Override
    public Parent getContent() {
        nextButton.setDisable(true);

        TextArea textArea = new TextArea();
        textArea.setWrapText(true);
        textArea.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                nextButton.setDisable(newValue.isEmpty());
            }
        });
        SurveyData.instance.complaints.bind(textArea.textProperty());
        VBox box = new VBox();
        box.setSpacing(5);
        box.getChildren().addAll(new Label("Please enter your complaints."), textArea);
        return box;
    }
}

class ThanksPage extends WizardPage {
    public ThanksPage() {
        super("Thanks");
    }

    @Override
    public Parent getContent() {
        StackPane stack = new StackPane();
        stack.getChildren().addAll(new Label("Thanks!"));
        VBox.setVgrow(stack, Priority.ALWAYS);
        return stack;
    }
}

public class SurveyWizard extends Wizard{
    Stage owner;

    public SurveyWizard(Stage owner) {
        super(new ComplaintsPage(), new MoreInformationPage(), new ThanksPage());
        this.owner = owner;
    }

    @Override
    public void finish() {
        System.out.println("Had complaint?" + SurveyData.instance.hasComplaints.get());
        if (SurveyData.instance.hasComplaints.get()) {
            System.out.println("Complatints: "
                + (SurveyData.instance.complaints.get().isEmpty() ? "No Details" : "\n" +
                SurveyData.instance.complaints.get()));
        }
        owner.close();
    }

    @Override
    public void cancel() {
        System.out.println("Cancelled");
        owner.close();
    }
}
