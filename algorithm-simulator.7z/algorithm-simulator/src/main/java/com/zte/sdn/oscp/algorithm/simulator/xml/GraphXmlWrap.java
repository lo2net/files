package com.zte.sdn.oscp.algorithm.simulator.xml;

import com.zte.sdn.oscp.algorithm.simulator.model.TestGraph;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

@XmlRootElement(name = "graphs")
public class GraphXmlWrap {
    private ObservableList<TestGraph> graphs = FXCollections.observableArrayList();

    public void initXmlMarshal() {
        graphs.stream().forEach(TestGraph::initXmlMarshal);
    }

    public void initXmlUnmarshal() {
        graphs.stream().forEach(TestGraph::initXmlUnmarshal);
    }

    @XmlElement(name = "graph")
    public ObservableList<TestGraph> getGraphs() {
        return graphs;
    }

    public void setGraphs(ObservableList<TestGraph> graphs) {
        this.graphs = graphs;
    }
}
