package com.zte.sdn.oscp.algorithm.test.algorithm;

import com.zte.sdn.oscp.algorithm.test.model.TestGraph;

public class CircleGraphGenerator implements GraphGenerator {
    @Override
    public void generateGraph(TestGraph graph) {
    }
}
