package com.zte.sdn.oscp.algorithm.test.controller;

import com.zte.sdn.oscp.algorithm.test.MainApp;
import com.zte.sdn.oscp.algorithm.test.model.TestSchedule;

import javafx.scene.image.Image;

public class WizardPageController {

    private String msg;
    private Image icon;

    protected MainApp mainApp;
    protected TestSchedule schedule;

    WizardPageController(String msg, String icon) {
        this.msg = msg;
        this.icon = new Image(icon);
    }

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

    public void setData(TestSchedule schedule) {
        this.schedule = schedule;
    }

    public void handleFinish() {}
    public void handleCancel() {}
    public void init() {}

    public String getMsg() {
        return msg;
    }
    public Image getIcon() {
        return icon;
    }
}
