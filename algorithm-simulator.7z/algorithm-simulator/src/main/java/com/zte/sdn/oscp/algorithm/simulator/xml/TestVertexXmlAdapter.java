package com.zte.sdn.oscp.algorithm.simulator.xml;

import com.zte.sdn.oscp.algorithm.simulator.model.TestVertex;
import com.zte.sdn.oscp.algorithm.simulator.shape.TestVertexShap;

import javax.xml.bind.annotation.adapters.XmlAdapter;


public class TestVertexXmlAdapter extends XmlAdapter<TestVertex.Coordinate, TestVertexShap> {
    @Override
    public TestVertex.Coordinate marshal(TestVertexShap shape) {
        TestVertex.Coordinate coord = new TestVertex.Coordinate();
        coord.setX(shape.getCircle().getCenterX());
        coord.setY(shape.getCircle().getCenterY());
        return coord;
    }

    @Override
    public TestVertexShap unmarshal(TestVertex.Coordinate coord) {
        TestVertexShap shape = new TestVertexShap();
        shape.getCircle().setCenterX(coord.getX());
        shape.getCircle().setCenterY(coord.getY());
        shape.reset();
        return shape;
    }

}
