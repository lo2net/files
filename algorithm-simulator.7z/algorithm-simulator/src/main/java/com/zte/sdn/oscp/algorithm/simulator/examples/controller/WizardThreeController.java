package com.zte.sdn.oscp.algorithm.simulator.examples.controller;

public class WizardThreeController implements WizardPageControllerExam {
    @Override
    public void handleFinish() {

    }

    @Override
    public void handleCancel() {

    }

    @Override
    public String getMsg() {
        return "最后一步!";
    }
}
