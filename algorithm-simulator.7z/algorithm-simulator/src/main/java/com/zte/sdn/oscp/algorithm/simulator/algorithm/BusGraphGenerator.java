package com.zte.sdn.oscp.algorithm.simulator.algorithm;

import com.zte.sdn.oscp.algorithm.simulator.model.TestGraph;

public class BusGraphGenerator implements GraphGenerator {
    @Override
    public void generateGraph(TestGraph graph) {
    }
}
