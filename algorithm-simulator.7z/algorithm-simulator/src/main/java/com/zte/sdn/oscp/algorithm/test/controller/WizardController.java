package com.zte.sdn.oscp.algorithm.test.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.stage.Stage;

public class WizardController {

    private Stage stage;
    private List<Region> pages = new ArrayList<>();
    private List<WizardPageController> controllers = new ArrayList<>();
    private int currentIdx = -1;
    private Stack<Integer> history = new Stack<Integer>();
    private boolean okClicked = false;

    public void setDialogStage(Stage stage) {
        this.stage = stage;
    }
    public boolean isOkClicked() {
        return okClicked;
    }

    public void AddPage(Region page, WizardPageController controller) {
        this.pages.add(page);
        this.controllers.add(controller);
    }

    public void init() {
        navTo(0);
        manageButtons();
    }

    @FXML
    private Button priorBtn;

    @FXML
    private Button nextBtn;

    @FXML
    private Button cancelBtn;

    @FXML
    private Label msg;

    @FXML
    private ImageView icon;

    @FXML
    public void handlePrior() {
        if (hasPriorPage()) {
            navTo(history.pop());
        }
    }

    @FXML
    public void handleNext() {
        if (hasNextPage()) {
            history.push(currentIdx);
            navTo(currentIdx + 1);
        } else {
            handleFinish();
        }
    }

    public void handleFinish() {
        for (WizardPageController controller : controllers) {
            controller.handleFinish();
        }
        stage.close();
        okClicked = true;
    }

    @FXML
    public void handleCancel() {
        for (WizardPageController controller : controllers) {
            controller.handleCancel();
        }
        stage.close();
    }

    public void manageButtons() {
        priorBtn.setDisable(true);
        nextBtn.setDisable(true);
        if (hasPriorPage()) {
            priorBtn.setDisable(false);
        }
        if (hasNextPage()) {
            nextBtn.setDisable(false);
        }

        // 最后一个page修改"下一步"按钮为"完成"
        if (currentIdx == (pages.size()-1)) {
            nextBtn.setDisable(false);
            nextBtn.setText("完成");
        } else {
            nextBtn.setText("下一步");
        }
    }

    private boolean hasPriorPage() {
        return !history.empty();
    }
    private boolean hasNextPage() {
        return currentIdx < (pages.size() -1) ;
    }

    private void navTo(int idx) {
        if (idx < 0 || idx >= pages.size()) {
            return;
        }

        Region nextPage = (Region)pages.get(idx);

        BorderPane rootLayout = (BorderPane)stage.getScene().getRoot();
        rootLayout.setCenter(nextPage);
        currentIdx = idx;

        // 设置标题栏
        msg.setText(controllers.get(idx).getMsg());
        // TODO: 设置图标
        icon.setImage(controllers.get(idx).getIcon());

        manageButtons();
    }
}
