package com.zte.sdn.oscp.algorithm.test.xml;

import com.zte.sdn.oscp.algorithm.framework.graph.Edge;
import com.zte.sdn.oscp.algorithm.test.model.TestEdge;
import com.zte.sdn.oscp.algorithm.test.model.TestGraph;

import java.util.HashMap;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class TestGraphXmlEdgeAdapter extends XmlAdapter<TestGraph.EdgeXmlData, HashMap<String, TestEdge>> {
    @Override
    public HashMap<String, TestEdge> unmarshal(TestGraph.EdgeXmlData v) {
        HashMap<String, TestEdge> edges = new HashMap<>();
        v.getEdges().forEach(edge ->
            edges.put(edge.getId(), edge)
        );
        return edges;
    }

    @Override
    public TestGraph.EdgeXmlData marshal(HashMap<String, TestEdge> edges) {
        TestGraph.EdgeXmlData data = new TestGraph.EdgeXmlData();
        edges.forEach((k, v)->
            data.getEdges().add(v)
        );
        return data;
    }
}
