package com.zte.sdn.oscp.algorithm.test.algorithm;

import com.zte.sdn.oscp.algorithm.binpacking.base.PathOptHandle;
import com.zte.sdn.oscp.algorithm.framework.graph.Edge;
import com.zte.sdn.oscp.algorithm.framework.request.CalcPathRequestBase;
import com.zte.sdn.oscp.algorithm.framework.result.Path;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestPathOptHandle implements PathOptHandle{

    private Map<String, Edge> edges;
    private Map<CalcPathRequestBase, List<Path>> requestPathsMap;


    public TestPathOptHandle(Map<CalcPathRequestBase, List<Path>> requestPathsMap, Map<String, Edge> edges) {
        this.edges = edges;
        this.requestPathsMap = requestPathsMap;
    }


    @Override
    public Map<String, Edge> loadAllEdges() {
        return edges;
    }

    @Override
    public Map<CalcPathRequestBase, List<Path>> loadAllReqsPaths() {
        return requestPathsMap;
    }

    @Override
    public Map<CalcPathRequestBase, Path> loadReqRunningPaths() {
        Map<CalcPathRequestBase, Path> requestPaths = new HashMap<CalcPathRequestBase, Path>();
        requestPathsMap.forEach((k, v) -> {
            requestPaths.put(k, v.get(0));
        });
        return requestPaths;
    }
}
