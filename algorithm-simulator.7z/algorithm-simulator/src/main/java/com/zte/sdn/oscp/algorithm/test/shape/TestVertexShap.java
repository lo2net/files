package com.zte.sdn.oscp.algorithm.test.shape;

import com.zte.sdn.oscp.algorithm.test.model.TestVertex;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextBoundsType;

public class TestVertexShap extends Group {
    private Circle circle = new Circle(10);
    private Text text = new Text();

    // TODO 保存一下上一次操作的节点的部分状态?
    private Paint previous = null;

    public void init(TestVertex vertex) {
        // 避免重复初始化导致错误
        if (null != getUserData()) {
            return;
        }
        setUserData(vertex);
        // 设置需要显示的节点名字text
        text.setText(vertex.getId());
        text.setMouseTransparent(true);
        text.setBoundsType(TextBoundsType.VISUAL);
        text.setX(circle.getCenterX() - text.getBoundsInLocal().getWidth()/2);
        text.setY(circle.getCenterY() + text.getBoundsInLocal().getHeight()/2);
        // TODO binding 该怎么写?
        //text.xProperty().bindBidirectional(circle.centerXProperty());
        //text.yProperty().bindBidirectional(circle.centerYProperty());
            /*
            text.xProperty().bind(
                Bindings.subtract(circle.centerXProperty(),
                    Bindings.selectDouble(text.boundsInLocalProperty(), "Width").divide(2)
                ));
            text.yProperty().bind(
                Bindings.add(circle.centerYProperty(),
                    Bindings.selectDouble(text.boundsInLocalProperty(), "Height").divide(2)
                ));
                */
        // TODO Binding 实质上也是weak listener
        circle.centerXProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                text.setX(newValue.doubleValue() - text.getBoundsInLocal().getWidth()/2);
                recalculate();
            }
        });
        circle.centerYProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                text.setY(newValue.doubleValue() + text.getBoundsInLocal().getHeight()/2);
                recalculate();
            }
        });

        getChildren().addAll(circle, text);
    }

    public void recalculate() {
        TestVertex vertex = (TestVertex) getUserData();
        vertex.getForwardEdges().stream().forEach(e ->
            e.getShape().calcLinePosition()
        );
        vertex.getBackwardEdges().stream().forEach(e ->
            e.getShape().calcLinePosition()
        );
    }
    // 恢复circle默认状态
    public void reset() {

        circle.setRadius(10);

        circle.setFill(Color.TRANSPARENT);
        circle.setStroke(Color.BLACK);
        circle.setStrokeWidth(1.0);

        //circle.setCursor(Cursor.HAND);
        text.setFont(Font.getDefault());
        text.setFill(Color.BLACK);
    }
    // 高亮circle
    public void setHighlight() {
        circle.setStroke(Color.CYAN);

        //text.setFont(new Font(text.getFont().getName(), text.getFont().getSize()+1));
        text.setFill(Color.CYAN);
    }
    // 选中/不选中circle
    public void switchSelected() {
        if (isSelected()) {
            setUnselected();
        } else {
            setSelected();
        }
    }
    public void setSelected() {
        // 保存
        previous = circle.getStroke();

        circle.setStroke(Color.YELLOW);
        text.setFill(Color.YELLOW);
    }
    public void setUnselected() {
        //circle.setStroke(Color.BLACK);
        circle.setStroke(previous);
        text.setFill(previous);
    }
    public boolean isSelected() {
        return circle.getStroke().equals(Color.YELLOW);
    }
    public void setFocus() {
        circle.setRadius(circle.getRadius() + 1);
        text.setFont(new Font(text.getFont().getName(), text.getFont().getSize()+2));
        //circle.setScaleX(1.1);
        //circle.setScaleY(1.1);
        //text.setScaleX(1.1);
        //text.setScaleY(1.1);
    }
    public void setUnfocus() {
        circle.setRadius(circle.getRadius() - 1);
        text.setFont(new Font(text.getFont().getName(), text.getFont().getSize()-2));
        //circle.setScaleX(1);
        //circle.setScaleY(1);
        //text.setScaleX(1);
        //text.setScaleY(1);
    }

    public Circle getCircle() {
        return circle;
    }
    public Text getText() {
        return text;
    }

    public void setForbidden() {
        circle.setStroke(Color.RED);
        text.setFill(Color.RED);
    }

    public void setMustpass() {
        circle.setStroke(Color.GREEN);
        text.setFill(Color.GREEN);
    }
}
