package com.zte.sdn.oscp.algorithm.test.xml;

import com.zte.sdn.oscp.algorithm.test.model.TestEdge;
import com.zte.sdn.oscp.algorithm.test.model.TestVertex;
import com.zte.sdn.oscp.algorithm.test.shape.TestEdgeShape;

import javax.xml.bind.annotation.adapters.XmlAdapter;


public class TestEdgeXmlAdapter extends XmlAdapter<TestEdge.LineData, TestEdgeShape> {
    @Override
    public TestEdgeShape unmarshal(TestEdge.LineData lineData) {
        TestEdgeShape shape = new TestEdgeShape();
        shape.getLine().setStartX(lineData.getStart().getX());
        shape.getLine().setStartY(lineData.getStart().getY());
        shape.getLine().setEndX(lineData.getEnd().getX());
        shape.getLine().setEndY(lineData.getEnd().getY());
        shape.reset();
        return shape;
    }
    @Override
    public TestEdge.LineData marshal(TestEdgeShape shape) {
        TestEdge.LineData data = new TestEdge.LineData();
        TestVertex.Coordinate start = new TestVertex.Coordinate();
        start.setX(shape.getLine().getStartX());
        start.setY(shape.getLine().getStartY());
        data.setStart(start);
        TestVertex.Coordinate end = new TestVertex.Coordinate();
        end.setX(shape.getLine().getEndX());
        end.setY(shape.getLine().getEndY());
        data.setEnd(end);
        return data;
    }
}
