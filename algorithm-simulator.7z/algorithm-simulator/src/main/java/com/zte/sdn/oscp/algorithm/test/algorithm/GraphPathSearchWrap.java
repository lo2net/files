package com.zte.sdn.oscp.algorithm.test.algorithm;

import com.zte.sdn.oscp.algorithm.adapter.route.RouteAlgorithmAdapter;
import com.zte.sdn.oscp.algorithm.adapter.route.impl.RouteAlgorithmAdapterImpl;
import com.zte.sdn.oscp.algorithm.framework.constraints.Affinity;
import com.zte.sdn.oscp.algorithm.framework.constraints.AffinityType;
import com.zte.sdn.oscp.algorithm.framework.constraints.BandWidthConstraint;
import com.zte.sdn.oscp.algorithm.framework.constraints.ConstraintBase;
import com.zte.sdn.oscp.algorithm.framework.constraints.ConstraintsHandle;
import com.zte.sdn.oscp.algorithm.framework.constraints.SlaveConstraint;
import com.zte.sdn.oscp.algorithm.framework.constraints.impl.DefaultBwConstraint;
import com.zte.sdn.oscp.algorithm.framework.constraints.impl.DefaultBwConstraintHandle;
import com.zte.sdn.oscp.algorithm.framework.constraints.impl.DefaultConstraintBase;
import com.zte.sdn.oscp.algorithm.framework.constraints.impl.DefaultSlaveConstraint;
import com.zte.sdn.oscp.algorithm.framework.graph.Edge;
import com.zte.sdn.oscp.algorithm.framework.graph.Vertex;
import com.zte.sdn.oscp.algorithm.framework.request.CalcPathRequestBase;
import com.zte.sdn.oscp.algorithm.framework.request.MetricReader;
import com.zte.sdn.oscp.algorithm.framework.request.impl.CalcPathReqImpl;
import com.zte.sdn.oscp.algorithm.framework.request.impl.DefaultEdgeWeightReader;
import com.zte.sdn.oscp.algorithm.framework.result.CalcFailType;
import com.zte.sdn.oscp.algorithm.framework.result.CalcPathResult;
import com.zte.sdn.oscp.algorithm.framework.result.Path;
import com.zte.sdn.oscp.algorithm.framework.strategy.CalculateStrategy;
import com.zte.sdn.oscp.algorithm.framework.strategy.impl.DefaultMetricStrategy;
import com.zte.sdn.oscp.algorithm.test.model.TestEdge;
import com.zte.sdn.oscp.algorithm.test.model.TestGraph;
import com.zte.sdn.oscp.algorithm.test.model.TestRequest;
import com.zte.sdn.oscp.algorithm.test.model.TestRoute;

import java.util.ArrayList;
import java.util.List;

public class GraphPathSearchWrap {

    public byte[] intToByteArray(int i) {
        byte[] result = new byte[4];
        result[0] = (byte) ((i >> 24) & 0xFF);
        result[1] = (byte) ((i >> 16) & 0xFF);
        result[2] = (byte) ((i >> 8) & 0xFF);
        result[3] = (byte) (i & 0xFF);
        return result;
    }

    public boolean pathSearch(TestGraph graph, TestRequest request) {
        // TODO oscp algorithm接口处理
        ConstraintBase<Vertex, Edge> constraintBase = new DefaultConstraintBase<>();
        BandWidthConstraint bwConstraint = new DefaultBwConstraint();
        // 带宽
        bwConstraint.setBandwidth(Integer.valueOf(request.getBandwidth()));
        constraintBase.setBwConstraint(bwConstraint);
        // 亲和力
        List<Affinity> affinityList = new ArrayList<>();
        if (request.getAffinity().get(0) != 0) {
            affinityList.add(new Affinity(AffinityType.INCLUDE_ALL, intToByteArray(request.getAffinity().get(0))));
        }
        if (request.getAffinity().get(1) != 0) {
            affinityList.add(new Affinity(AffinityType.INCLUDE_ANY, intToByteArray(request.getAffinity().get(1))));
        }
        if (request.getAffinity().get(2) != 0) {
            affinityList.add(new Affinity(AffinityType.EXCLUDE_ANY, intToByteArray(request.getAffinity().get(2))));
        }
        if(!affinityList.isEmpty()) {
            constraintBase.setAffinityList(affinityList);
        }

        MetricReader metricReader= new DefaultEdgeWeightReader();

        CalculateStrategy<Vertex, Edge> calculateStrategy= new DefaultMetricStrategy<>();

        ConstraintsHandle constraintsHandle = new DefaultBwConstraintHandle();

        CalcPathRequestBase<Vertex, Edge> calcPathRequestBase = new CalcPathReqImpl<>();
        calcPathRequestBase.setGraph(graph);
        // 起点
        Vertex A = graph.getVertex(request.getRequestStart());
        calcPathRequestBase.setSrc(A);
        // 终点
        Vertex Z = graph.getVertex(request.getRequestEnd());
        calcPathRequestBase.setDst(Z);
        calcPathRequestBase.setMasterConstraint(constraintBase);
        calcPathRequestBase.setCalculateStrategy(calculateStrategy);
        calcPathRequestBase.setConstraintsHandle(constraintsHandle);
        calcPathRequestBase.setMetricReader(metricReader);
        // K优值
        if (request.getAlgKNumber() == -1) { // 尽量分离
            SlaveConstraint<Vertex, Edge> slaveConstraint = new DefaultSlaveConstraint<>();
            slaveConstraint.setDisjoint(false);
            calcPathRequestBase.setSlaveConstraint(slaveConstraint);
        } else if (request.getAlgKNumber() == -2) { // 完全分离
            SlaveConstraint<Vertex, Edge> slaveConstraint = new DefaultSlaveConstraint<>();
            slaveConstraint.setDisjoint(true);
            calcPathRequestBase.setSlaveConstraint(slaveConstraint);
        } else {
            calcPathRequestBase.setPathNum(request.getAlgKNumber());
        }

        // 算法接口
        RouteAlgorithmAdapter routeAlgorithmAdapter = new RouteAlgorithmAdapterImpl();
        // 调用
        try {
            CalcPathResult calcPathResult = routeAlgorithmAdapter.calcPath(calcPathRequestBase);
            // 处理结果
            //Assert.assertEquals(calcPathResult.getMasterPaths().get(0).toString(), "A->B, B->C, C->E, E->F, ");
            convertResult(calcPathResult, request);
        } catch (Exception ex) {
            return false;
        }
        return true;
    }

    private void convertResult(CalcPathResult<Vertex, Edge> calcPathResult, TestRequest request) {

        // TODO 转换结果
        int i = 0;
        for (Path<Vertex, Edge> path : calcPathResult.getMasterPaths()) {
            TestRoute route = new TestRoute();
            route.setBelongRequest(request);
            if (path.getCalcFailType() == CalcFailType.NO_PATH) {
                route.setName("NO_PATH");
            } else {
                route.setName("route: " + String.valueOf(i++));
                route.setRequestStart(request.getRequestStart());
                route.setRequestEnd(request.getRequestEnd());
            }
            for (Edge edge : path.getEdgeList()) {
                route.getLcs().add(edge.getId());
                // 如果是双向业务, 把反向边也加到结果中
                if (request.isBidirection()) {
                    TestEdge reverseEdge = ((TestEdge)edge).getReverse();
                    if (null!=reverseEdge) {
                        route.getLcs().add(reverseEdge.getId());
                    }
                }
            }
            request.getRoute().add(route);
        }
    }
}
