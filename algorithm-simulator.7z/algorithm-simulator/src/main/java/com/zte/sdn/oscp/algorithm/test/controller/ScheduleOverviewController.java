package com.zte.sdn.oscp.algorithm.test.controller;

import com.zte.sdn.oscp.algorithm.test.MainApp;
import com.zte.sdn.oscp.algorithm.test.model.TestRequest;
import com.zte.sdn.oscp.algorithm.test.model.TestSchedule;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.ProgressBarTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DataFormat;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;

public class ScheduleOverviewController {

    @FXML
    private TableView<TestSchedule> scheduleTable;
    @FXML
    private TableColumn needExecuteSchedule;
    @FXML
    private TableColumn scheduleName;
    @FXML
    private TableColumn graphName;
    @FXML
    private TableColumn stockCounts;
    @FXML
    private TableColumn createCounts;
    @FXML
    private TableColumn progress;

    @FXML
    private TableView<TestRequest> requestTable;
    @FXML
    private TableColumn needExecuteRequest;
    @FXML
    private TableColumn algKNumber;
    @FXML
    private TableColumn needOptimize;
    @FXML
    private TableColumn requestId;
    @FXML
    private TableColumn requestStart;
    @FXML
    private TableColumn requestEnd;
    @FXML
    private TableColumn<TestRequest, String> direction;

    private ObservableList<TestSchedule> data = null;

    private MainApp mainApp;
    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

    private static final DataFormat SERIALIZED_MIME_TYPE = new DataFormat("application/x-java-serialized-object");
    @FXML
    void initialize() {

        needExecuteSchedule.setCellValueFactory(new PropertyValueFactory<>("needExecuteSchedule"));
        needExecuteSchedule.setCellFactory(CheckBoxTableCell.forTableColumn(needExecuteSchedule));
        scheduleName.setCellValueFactory(new PropertyValueFactory<>("scheduleName"));
        graphName.setCellValueFactory(new PropertyValueFactory<>("graphName"));
        stockCounts.setCellValueFactory(new PropertyValueFactory<>("stockCounts"));
        createCounts.setCellValueFactory(new PropertyValueFactory<>("createCounts"));
        progress.setCellValueFactory(new PropertyValueFactory<>("progress"));
        progress.setCellFactory(ProgressBarTableCell.forTableColumn());

        // 根据scheduleTable选中的行,在requestTable中显示关联内容
        scheduleTable.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                int index = scheduleTable.getSelectionModel().getSelectedIndex();
                if (-1 != index) {
                    requestTable.setItems(((TestSchedule) newValue).getRequests());
                } else {
                    requestTable.setItems(null);
                }
            }
        });
        enableDragAndDrop(scheduleTable);
        enableDragAndDrop(requestTable);

        // 这个方法虽然不好看,但是能解决问题!
        // TODO 目前还有一个问题: 如果在tableview的标题栏点击, 会显示"删除"菜单
        //*
        ContextMenu cmCreate = new ContextMenu();
        MenuItem create = new MenuItem("添加schedule");
        create.setOnAction((ActionEvent e) -> {
            TestSchedule schedule = mainApp.showScheduleCreate();
            if (null != schedule) {
                scheduleTable.getItems().add(schedule);
                scheduleTable.getSelectionModel().select(scheduleTable.getItems().size() - 1);
            }
        });
        cmCreate.getItems().add(create);

        ContextMenu cmDelete = new ContextMenu();
        MenuItem delete = new MenuItem("删除schedule");
        delete.setOnAction((ActionEvent e) -> {
            int index = scheduleTable.getSelectionModel().getSelectedIndex();
            if (index != -1) {
                scheduleTable.getItems().remove(index);
            }
        });
        cmDelete.getItems().add(delete);

        scheduleTable.addEventHandler(MouseEvent.MOUSE_CLICKED, (MouseEvent e)-> {
            // 先把所有菜单隐藏
            cmCreate.hide();
            cmDelete.hide();

            // 判断当前点击的位置
            boolean bInEmptyRow = false;
            if (e.getTarget() instanceof TableCell) {
                TableCell cell = (TableCell)e.getTarget();
                bInEmptyRow = cell.getTableRow().getIndex() >= scheduleTable.getItems().size();
            }
            if (e.getTarget() instanceof StackPane) {
                bInEmptyRow = true;
            }

            if (bInEmptyRow) {
                scheduleTable.getSelectionModel().clearSelection();
            }

            if ((e.getClickCount() > 1) && !bInEmptyRow) { // 有记录的行上双击
                mainApp.showScheduleInfo(scheduleTable.getSelectionModel().getSelectedItem());
            } else {
                if (e.getButton() == MouseButton.SECONDARY) { // 右键点击
                    if (!bInEmptyRow) {
                        cmDelete.show(scheduleTable, e.getScreenX(), e.getScreenY());
                    } else {
                        cmCreate.show(scheduleTable, e.getScreenX(), e.getScreenY());
                    }
                }
            }
        });
        //*/

        scheduleTable.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

            }
        });

        scheduleTable.setPlaceholder(new Text("当前无记录! 请使用右键菜单进行配置!"));

        needExecuteRequest.setCellValueFactory(new PropertyValueFactory<>("needExecuteRequest"));
        needExecuteRequest.setCellFactory(CheckBoxTableCell.forTableColumn(needExecuteRequest));
        algKNumber.setCellValueFactory(new PropertyValueFactory<>("algKNumber"));
        needOptimize.setCellValueFactory(new PropertyValueFactory<>("needOptimize"));
        needOptimize.setCellFactory(CheckBoxTableCell.forTableColumn(needOptimize));
        requestId.setCellValueFactory(new PropertyValueFactory<>("requestId"));
        requestStart.setCellValueFactory(new PropertyValueFactory<>("requestStart"));
        requestEnd.setCellValueFactory(new PropertyValueFactory<>("requestEnd"));
        direction.setCellValueFactory(new PropertyValueFactory<>("direction"));
    }

    private <T> void enableDragAndDrop(TableView<T> tableView) {
        // 拖动行
        tableView.setRowFactory( tv -> {
            TableRow row = new TableRow<>();
            row.setOnDragDetected(event -> {
                if (!row.isEmpty()) {
                    Integer index = row.getIndex();
                    Dragboard db = row.startDragAndDrop(TransferMode.MOVE);
                    db.setDragView(row.snapshot(null, null));
                    ClipboardContent cc = new ClipboardContent();
                    cc.put(SERIALIZED_MIME_TYPE, index);
                    db.setContent(cc);
                    event.consume();
                }
            });
            row.setOnDragOver(event -> {
                Dragboard db = event.getDragboard();
                if (db.hasContent(SERIALIZED_MIME_TYPE)) {
                    if (row.getIndex() != ((Integer)db.getContent(SERIALIZED_MIME_TYPE)).intValue()) {
                        event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
                        event.consume();
                    }
                }
            });
            row.setOnDragDropped(event -> {
                Dragboard db = event.getDragboard();
                if (db.hasContent(SERIALIZED_MIME_TYPE)) {
                    int draggedIndex = (Integer)db.getContent(SERIALIZED_MIME_TYPE);
                    T data = tableView.getItems().remove(draggedIndex);
                    int dropIndex;
                    if (row.isEmpty()) {
                        dropIndex = tableView.getItems().size();
                    } else {
                        dropIndex = row.getIndex();
                    }
                    tableView.getItems().add(dropIndex, data);
                    event.setDropCompleted(true);
                    tableView.getSelectionModel().select(dropIndex);
                    event.consume();
                }
            });

            // 下面这个方法设置contextmenu只能在row上,如果tableview空的话就没办法
            /*
            ContextMenu cmCreate = new ContextMenu();
            MenuItem create = new MenuItem("添加schedule");
            create.setOnAction((ActionEvent e) -> {
                TestSchedule schedule = mainApp.showScheduleCreate();
                if (null != schedule) {
                    scheduleTable.getItems().add(schedule);
                    scheduleTable.getSelectionModel().select(scheduleTable.getItems().size() - 1);
                }
            });
            cmCreate.getItems().add(create);

            ContextMenu cmDelete = new ContextMenu();
            MenuItem delete = new MenuItem("删除schedule");
            delete.setOnAction((ActionEvent e) -> {
                int index = scheduleTable.getSelectionModel().getSelectedIndex();
                if (index != -1) {
                    scheduleTable.getItems().remove(index);
                }
            });
            cmDelete.getItems().add(delete);

            row.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    int index = row.getIndex();
                    boolean bInEmptyRow = (index >= scheduleTable.getItems().size());
                    if (event.getButton() == MouseButton.SECONDARY) { // 右键点击
                        if (bInEmptyRow) {
                            cmCreate.show(scheduleTable, event.getScreenX(), event.getScreenY());
                        } else {
                            cmDelete.show(scheduleTable, event.getScreenX(), event.getScreenY());
                        }
                    }
                    if ((event.getClickCount() > 1) && !bInEmptyRow) { // 有记录的行上双击
                        mainApp.showScheduleInfo(scheduleTable.getSelectionModel().getSelectedItem());
                    }
                }
            });
            */
            return row;
        });
    }

    public void setData(ObservableList<TestSchedule> schedules) {
        data = schedules;
        if (null != data) {
            scheduleTable.setItems(data);
            if (!data.isEmpty()) {
                requestTable.setItems(data.get(0).getRequests());
            }
        }
    }
    public ObservableList getData() {
        return data;
    }
}
