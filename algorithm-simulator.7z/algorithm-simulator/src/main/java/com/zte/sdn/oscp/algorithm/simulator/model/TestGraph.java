package com.zte.sdn.oscp.algorithm.simulator.model;


import com.zte.sdn.oscp.algorithm.framework.graph.Edge;
import com.zte.sdn.oscp.algorithm.framework.graph.GeneralGraph;
import com.zte.sdn.oscp.algorithm.framework.graph.Vertex;
import com.zte.sdn.oscp.algorithm.framework.result.Path;
import com.zte.sdn.oscp.algorithm.simulator.xml.TestGraphXmlEdgeAdapter;
import com.zte.sdn.oscp.algorithm.simulator.xml.TestGraphXmlVertexAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import edu.uci.ics.jung.graph.util.EdgeType;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

// 图的定义
public class TestGraph extends GeneralGraph<Vertex, Edge> {
    // 下面这些字段主要是用来描述graph类型的,在用户选择创建的之后用来生成相关的数据
    // 标识
    private SimpleStringProperty name = new SimpleStringProperty("");
    // 拓扑类型
    private SimpleStringProperty topoType = new SimpleStringProperty("");
    // 节点数
    private SimpleIntegerProperty vertexCounts = new SimpleIntegerProperty(0);
    // 双向链路
    private SimpleStringProperty direction = new SimpleStringProperty("单向");
    // 平均连接度
    private SimpleIntegerProperty averageConnectionRatio = new SimpleIntegerProperty(0);
    // 带宽范围
    private SimpleStringProperty bandWidth = new SimpleStringProperty("0");
    // 时延范围
    private SimpleStringProperty timeDelay = new SimpleStringProperty("0");
    // 权值范围
    private SimpleStringProperty weight = new SimpleStringProperty("");
    // 亲和力范围
    private SimpleStringProperty affinity = new SimpleStringProperty("");
    // 优化阈值
    private SimpleStringProperty optimizeThreshold = new SimpleStringProperty("0");

    // 保存已经创建了的业务
    // 待创建业务列表
    private ObservableList<TestRequest> services = FXCollections.observableArrayList();
    private HashMap<String, TestEdge> edgesForXml = new HashMap<>();
    private HashMap<String, TestVertex> vertexesForXml = new HashMap<>();

    public TestGraph() {
        super("graphKey缺省名称");
    }

    public TestGraph(String graphKey) {
        super(graphKey);
    }

    // 是否双向
    public boolean biDirection() {
        return getDirection().equals("双向");
    }

    public String getDirection() {
        return direction.get();
    }

    public void setDirection(String direction) {
        this.direction.set(direction);
    }

    public SimpleStringProperty directionProperty() {
        return direction;
    }

    public String getOptimizeThreshold() {
        return optimizeThreshold.get();
    }

    public void setOptimizeThreshold(String optimizeThreshold) {
        this.optimizeThreshold.set(optimizeThreshold);
    }

    public SimpleStringProperty optimizeThresholdProperty() {
        return optimizeThreshold;
    }

    public String getWeight() {
        return weight.get();
    }

    public void setWeight(String weight) {
        this.weight.set(weight);
    }

    public SimpleStringProperty weightProperty() {
        return weight;
    }

    public String getAffinity() {
        return affinity.get();
    }

    public void setAffinity(String affinity) {
        this.affinity.set(affinity);
    }

    public SimpleStringProperty affinityProperty() {
        return affinity;
    }

    @XmlElementWrapper(name = "services")
    @XmlElement(name = "service")
    public ObservableList<TestRequest> getServices() {
        return services;
    }

    public void setServices(ObservableList<TestRequest> services) {
        this.services = services;
    }

    @XmlJavaTypeAdapter(TestGraphXmlEdgeAdapter.class)
    public HashMap<String, TestEdge> getEdgesForXml() {
        return edgesForXml;
    }

    public void setEdgesForXml(HashMap<String, TestEdge> edgesForXml) {
        this.edgesForXml = edgesForXml;
    }

    @XmlJavaTypeAdapter(TestGraphXmlVertexAdapter.class)
    public HashMap<String, TestVertex> getVertexesForXml() {
        return vertexesForXml;
    }

    public void setVertexesForXml(HashMap<String, TestVertex> vertexesForXml) {
        this.vertexesForXml = vertexesForXml;
    }

    public void initXmlMarshal() {
        if (edgesForXml.isEmpty()) {
            for (Edge edge : getEdges()) {
                edgesForXml.put(getEdgeId(edge), (TestEdge) edge);
            }
        }
        if (vertexesForXml.isEmpty()) {
            for (Vertex vertex : getVertices()) {
                vertexesForXml.put(getVertexId(vertex), (TestVertex) vertex);
            }
        }
    }

    public void initXmlUnmarshal() {
        // 先添加点
        for (Map.Entry<String, TestVertex> entry : vertexesForXml.entrySet()) {
            Vertex vertex = entry.getValue();
            if (null == getVertex(vertex.getId())) {
                ((TestVertex) vertex).init();
                addVertex(vertex);
            }
        }
        // 需要替换掉edgesForXml中的点, 因为xxxForXml都会自己生成vertex数据不一致
        for (Map.Entry<String, TestEdge> entry : edgesForXml.entrySet()) {
            Edge edge = entry.getValue();
            if (null == getEdge(edge.getId())) {
                // 先从map中查找是否已经存在vertex, 不存在才能添加
                Vertex src = getVertex(edge.getSrc().getId());
                if (null != src) {
                    ((TestEdge) edge).setSrc((TestVertex) src);
                    ((TestVertex) src).init();
                }
                Vertex dst = getVertex(edge.getDst().getId());
                if (null != dst) {
                    ((TestEdge) edge).setDst((TestVertex) dst);
                    ((TestVertex) dst).init();
                }
                ((TestEdge) edge).init();
                addEdge(edge, src, dst, EdgeType.DIRECTED);

                // 绘制需要的数据
                TestVertex vStart = (TestVertex) edge.getSrc();
                vStart.getForwardEdges().add((TestEdge) edge);
                TestVertex vEnd = (TestVertex) edge.getDst();
                vEnd.getBackwardEdges().add((TestEdge) edge);
            }
        }

        // 处理双向边正反向关系
        if (biDirection()) {
            for (Edge edgeLoop : getEdges()) {
                TestEdge edge = (TestEdge) edgeLoop;
                if (null != edge.getReverse()) {
                    continue;
                }
                // 查找反向边
                boolean bFind = false;
                for (TestEdge reverseEdge : edge.getDst().getForwardEdges()) {
                    if (reverseEdge.getDst() == edge.getSrc()) {
                        bFind = true;
                        edge.setReverse(reverseEdge);
                        reverseEdge.setReverse(edge);
                        break;
                    }
                }
                if (!bFind) {
                    // TODO 数据错误?
                    System.out.println("双向图 " + getName() + " 数据存在错误: " + edge.getId() + " 没有反向边!");
                    System.exit(-1);
                }
            }
        }

        // 处理request
        for (TestRequest request : getServices()) {
            request.setBelongGraph(this);
        }
    }

    // 实现父类的几个方法:
    @Override
    public String getEdgeId(Edge edge) {
        return edge.getId();
    }

    @Override
    public String getVertexId(Vertex vertex) {
        return vertex.getId();
    }

    @Override
    public List<Edge> findSRLGLinks(Path<Vertex, Edge> masterPath, GeneralGraph<Vertex, Edge> graph) {
        return new ArrayList<>();
    }

    // 下面都是自动生成的get/set/property代码
    public String getName() {
        return name.get();
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public SimpleStringProperty nameProperty() {
        return name;
    }

    public String getTopoType() {
        return topoType.get();
    }

    public void setTopoType(String topoType) {
        this.topoType.set(topoType);
    }

    public SimpleStringProperty topoTypeProperty() {
        return topoType;
    }

    public int getVertexCounts() {
        return vertexCounts.get();
    }

    public void setVertexCounts(int vertexCounts) {
        this.vertexCounts.set(vertexCounts);
    }

    public SimpleIntegerProperty vertexCountsProperty() {
        return vertexCounts;
    }

    public int getAverageConnectionRatio() {
        return averageConnectionRatio.get();
    }

    public void setAverageConnectionRatio(int averageConnectionRatio) {
        this.averageConnectionRatio.set(averageConnectionRatio);
    }

    public SimpleIntegerProperty averageConnectionRatioProperty() {
        return averageConnectionRatio;
    }

    public String getBandWidth() {
        return bandWidth.get();
    }

    public void setBandWidth(String bandWidth) {
        this.bandWidth.set(bandWidth);
    }

    public SimpleStringProperty bandWidthProperty() {
        return bandWidth;
    }

    public String getTimeDelay() {
        return timeDelay.get();
    }

    public void setTimeDelay(String timeDelay) {
        this.timeDelay.set(timeDelay);
    }

    public SimpleStringProperty timeDelayProperty() {
        return timeDelay;
    }

    // 如果父类支持jaxb xml读写的话就不用这么写了...
    public static class EdgeXmlData {
        private List<TestEdge> edges = new ArrayList<>();

        @XmlElementWrapper(name = "edges")
        @XmlElement(name = "edge")
        public List<TestEdge> getEdges() {
            return edges;
        }

        public void setEdges(List<TestEdge> edges) {
            this.edges = edges;
        }
    }

    public static class VertexXmlData {
        private List<TestVertex> vertexes = new ArrayList<>();

        @XmlElementWrapper(name = "vertexes")
        @XmlElement(name = "vertex")
        public List<TestVertex> getVertexes() {
            return vertexes;
        }

        public void setVertexes(List<TestVertex> vertexes) {
            this.vertexes = vertexes;
        }
    }
}
