package com.zte.sdn.oscp.algorithm.simulator.controller;

import com.zte.sdn.oscp.algorithm.simulator.MainApp;
import com.zte.sdn.oscp.algorithm.simulator.model.TestEdge;
import com.zte.sdn.oscp.algorithm.simulator.model.TestGraph;
import com.zte.sdn.oscp.algorithm.simulator.model.TestRequest;
import com.zte.sdn.oscp.algorithm.simulator.model.TestRoute;
import com.zte.sdn.oscp.algorithm.simulator.model.TestSchedule;
import com.zte.sdn.oscp.algorithm.simulator.model.TestVertex;

import javafx.beans.binding.Bindings;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;

public class ScheduleInfoController {

    // graph显示
    @FXML
    ScrollPane scrollPane;
    @FXML
    AnchorPane pane;
    @FXML
    private TableView<TestRequest> requestTableView;
    @FXML
    private TableColumn idCol;
    @FXML
    private TableColumn startCol;
    @FXML
    private TableColumn endCol;
    @FXML
    private TableColumn directionCol;
    @FXML
    private TableColumn priorityCol;
    @FXML
    private TableColumn weightCol;
    @FXML
    private TableColumn bandwidthCol;
    @FXML
    private TableColumn affinityCol;
    @FXML
    private TableColumn timedelayCol;
    @FXML
    private TableView<TestRequest.Constraint> constraintTableView;
    @FXML
    private TableColumn masterSlaveCol;
    @FXML
    private TableColumn nodeTypeCol;
    @FXML
    private TableColumn nodeNameCol;
    @FXML
    private TableColumn constraintTypeCol;
    private TestSchedule data;

    private MainApp mainApp;
    private Stage dialog;

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

    public void setDialog(Stage dialog) {
        this.dialog = dialog;
    }

    @FXML
    void handleCreateRequest(ActionEvent event) {
        TestRequest request = new TestRequest();
        request.setBelongGraph(mainApp.getGraph(data.getGraphName()));
        if (mainApp.showRequestCreate(dialog, request)) {
            data.getRequests().add(request);
            data.setCreateCounts(data.getCreateCounts() + 1);
        }
    }

    @FXML
    void handleDeleteRequest(ActionEvent event) {
        TestRequest request = requestTableView.getSelectionModel().getSelectedItem();
        // 同时要更新request计数器, 区分是create还是stock数据
        if (request.isDeployed()) {
            data.setStockCounts(data.getStockCounts() - 1);
        } else {
            data.setCreateCounts(data.getCreateCounts() - 1);
        }
        data.getRequests().remove(request);
    }

    public void initialize() {

        idCol.setCellValueFactory(new PropertyValueFactory<>("requestId"));
        startCol.setCellValueFactory(new PropertyValueFactory<>("requestStart"));
        endCol.setCellValueFactory(new PropertyValueFactory<>("requestEnd"));
        directionCol.setCellValueFactory(new PropertyValueFactory<>("direction"));
        priorityCol.setCellValueFactory(new PropertyValueFactory<>("priority"));
        weightCol.setCellValueFactory(new PropertyValueFactory<>("weight"));
        bandwidthCol.setCellValueFactory(new PropertyValueFactory<>("bandwidth"));
        affinityCol.setCellValueFactory(new PropertyValueFactory<>("affinity"));
        timedelayCol.setCellValueFactory(new PropertyValueFactory<>("timedelay"));

        requestTableView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<TestRequest>() {
            @Override
            public void changed(ObservableValue<? extends TestRequest> observable, TestRequest oldValue, TestRequest newValue) {

                constraintTableView.setPlaceholder(new Text("当前无约束条件数据!\n\n\n图中选择右键菜单配置!"));
                constraintTableView.setItems(newValue.getConstraints());

                if (null != newValue) {
                    setNew(newValue);
                }
            }
        });

        masterSlaveCol.setCellValueFactory(new PropertyValueFactory<>("masterSlave"));
        nodeTypeCol.setCellValueFactory(new PropertyValueFactory<>("nodeType"));
        nodeNameCol.setCellValueFactory(new PropertyValueFactory<>("nodeName"));
        constraintTypeCol.setCellValueFactory(new PropertyValueFactory<>("type"));

        constraintTableView.setPlaceholder(new Text("请先选中对应业务!"));

        constraintTableView.setRowFactory(new Callback<TableView<TestRequest.Constraint>, TableRow<TestRequest.Constraint>>() {
            @Override
            public TableRow<TestRequest.Constraint> call(TableView<TestRequest.Constraint> param) {
                final TableRow<TestRequest.Constraint> row = new TableRow<>();
                final ContextMenu menu = new ContextMenu();
                MenuItem delete = new MenuItem("删除");
                delete.setOnAction((ActionEvent e) -> {
                    TestRequest.Constraint constraint = constraintTableView.getSelectionModel().getSelectedItem();
                    if (null != constraint) {
                        if (constraint.isVertex()) {
                            TestVertex vertex = (TestVertex) mainApp.getGraph(data.getGraphName()).getVertex(constraint.getNodeName());
                            vertex.getShape().reset();
                        }
                        if (constraint.isEdge()) {
                            TestEdge edge = (TestEdge) mainApp.getGraph(data.getGraphName()).getEdge(constraint.getNodeName());
                            edge.getShape().reset();
                        }
                        constraintTableView.getItems().remove(constraint);
                    }
                });
                menu.getItems().add(delete);

                row.contextMenuProperty().bind(
                    Bindings.when(Bindings.isNotNull(row.itemProperty()))
                        .then(menu)
                        .otherwise(((ContextMenu) null)));
                return row;
            }
        });
    }

    public void clear() {
        // 高亮业务的az点
        TestGraph graph = mainApp.getGraph(data.getGraphName());
        graph.getVertices().stream().forEach(v ->
            ((TestVertex) v).getShape().reset()
        );
        graph.getEdges().stream().forEach(e ->
            ((TestEdge) e).getShape().reset()
        );
    }

    public void setNew(TestRequest request) {
        // 重新加载graph
        mainApp.loadGraph();
        TestGraph graph = mainApp.getGraph(data.getGraphName());
        if (null != graph) {
            // 菜单
            ContextMenu vertexMenu = new ContextMenu();
            {
                MenuItem mustpassItem = new MenuItem("设置节点必经");
                mustpassItem.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        TestVertex vertex = (TestVertex) vertexMenu.getUserData();
                        constraintTableView.getItems().add(
                            (new TestRequest.Constraint()).setMaster().setVertex(vertex.getId()).setMustpass());
                        vertex.getShape().setMustpass();
                    }
                });
                vertexMenu.getItems().add(mustpassItem);
                MenuItem forbiddenItem = new MenuItem("设置节点禁止");
                forbiddenItem.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        TestVertex vertex = (TestVertex) vertexMenu.getUserData();
                        constraintTableView.getItems().add(
                            (new TestRequest.Constraint()).setMaster().setVertex(vertex.getId()).setForbidden());
                        vertex.getShape().setForbidden();
                    }
                });
                vertexMenu.getItems().add(forbiddenItem);
            }
            // master/slave
            ContextMenu msvertexMenu = new ContextMenu();
            {
                MenuItem mustpassItem = new MenuItem("设置主用节点必经");
                mustpassItem.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        TestVertex vertex = (TestVertex) msvertexMenu.getUserData();
                        constraintTableView.getItems().add(
                            (new TestRequest.Constraint()).setMaster().setVertex(vertex.getId()).setMustpass());
                        vertex.getShape().setMustpass();
                    }
                });
                msvertexMenu.getItems().add(mustpassItem);
                MenuItem msmustpassItem = new MenuItem("设置备用节点必经");
                msmustpassItem.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        TestVertex vertex = (TestVertex) msvertexMenu.getUserData();
                        constraintTableView.getItems().add(
                            (new TestRequest.Constraint()).setSlave().setVertex(vertex.getId()).setMustpass());
                        vertex.getShape().setMustpass();
                    }
                });
                msvertexMenu.getItems().add(msmustpassItem);
                MenuItem forbiddenItem = new MenuItem("设置主用节点禁止");
                forbiddenItem.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        TestVertex vertex = (TestVertex) msvertexMenu.getUserData();
                        constraintTableView.getItems().add(
                            (new TestRequest.Constraint()).setMaster().setVertex(vertex.getId()).setForbidden());
                        vertex.getShape().setForbidden();
                    }
                });
                msvertexMenu.getItems().add(forbiddenItem);
                MenuItem msforbiddenItem = new MenuItem("设置备用节点禁止");
                msforbiddenItem.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        TestVertex vertex = (TestVertex) msvertexMenu.getUserData();
                        constraintTableView.getItems().add(
                            (new TestRequest.Constraint()).setSlave().setVertex(vertex.getId()).setForbidden());
                        vertex.getShape().setForbidden();
                    }
                });
                msvertexMenu.getItems().add(msforbiddenItem);
            }

            ContextMenu edgeMenu = new ContextMenu();
            {
                MenuItem mustpassItem = new MenuItem("设置边必经");
                mustpassItem.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        TestEdge edge = (TestEdge) edgeMenu.getUserData();
                        constraintTableView.getItems().add(
                            (new TestRequest.Constraint()).setMaster().setEdge(edge.getId()).setMustpass());
                        edge.getShape().setMustpass();
                    }
                });
                edgeMenu.getItems().add(mustpassItem);
                MenuItem forbiddenItem = new MenuItem("设置边禁止");
                forbiddenItem.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        TestEdge edge = (TestEdge) edgeMenu.getUserData();
                        constraintTableView.getItems().add(
                            (new TestRequest.Constraint()).setMaster().setEdge(edge.getId()).setForbidden());
                        edge.getShape().setForbidden();
                    }
                });
                edgeMenu.getItems().add(forbiddenItem);
            }
            ContextMenu msedgeMenu = new ContextMenu();
            {
                MenuItem mustpassItem = new MenuItem("设置主用边必经");
                mustpassItem.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        TestEdge edge = (TestEdge) msedgeMenu.getUserData();
                        constraintTableView.getItems().add(
                            (new TestRequest.Constraint()).setMaster().setEdge(edge.getId()).setMustpass());
                        edge.getShape().setMustpass();
                    }
                });
                msedgeMenu.getItems().add(mustpassItem);
                MenuItem msmustpassItem = new MenuItem("设置备用边必经");
                msmustpassItem.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        TestEdge edge = (TestEdge) msedgeMenu.getUserData();
                        constraintTableView.getItems().add(
                            (new TestRequest.Constraint()).setSlave().setEdge(edge.getId()).setMustpass());
                        edge.getShape().setMustpass();
                    }
                });
                msedgeMenu.getItems().add(msmustpassItem);
                MenuItem forbiddenItem = new MenuItem("设置主用边禁止");
                forbiddenItem.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        TestEdge edge = (TestEdge) msedgeMenu.getUserData();
                        constraintTableView.getItems().add(
                            (new TestRequest.Constraint()).setMaster().setEdge(edge.getId()).setForbidden());
                        edge.getShape().setForbidden();
                    }
                });
                msedgeMenu.getItems().add(forbiddenItem);
                MenuItem msforbiddenItem = new MenuItem("设置备用边禁止");
                msforbiddenItem.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        TestEdge edge = (TestEdge) msedgeMenu.getUserData();
                        constraintTableView.getItems().add(
                            (new TestRequest.Constraint()).setSlave().setEdge(edge.getId()).setForbidden());
                        edge.getShape().setForbidden();
                    }
                });
                msedgeMenu.getItems().add(msforbiddenItem);
            }
            GraphManageController.showGraphView(scrollPane, pane, graph, null, null,
                (p) -> {
                    return (null != requestTableView.getSelectionModel().getSelectedItem()) ?
                        (requestTableView.getSelectionModel().getSelectedItem().getAlgKNumber() < 1 ? msvertexMenu : vertexMenu) : null;
                },
                (p) -> {
                    return (null != requestTableView.getSelectionModel().getSelectedItem()) ?
                        (requestTableView.getSelectionModel().getSelectedItem().getAlgKNumber() < 1 ? msedgeMenu : edgeMenu) : null;
                });

            // 高亮业务的az点
            TestVertex requestStart = (TestVertex) graph.getVertex(request.getRequestStart());
            if (null != requestStart) {
                requestStart.getShape().setHighlight();
            }
            TestVertex requestEnd = (TestVertex) graph.getVertex(request.getRequestEnd());
            if (null != requestEnd) {
                requestEnd.getShape().setHighlight();
            }
        }

        // 正常情况下,应该只有一条路由
        for (TestRoute route : request.getRoute()) {
            if (null != route) {
                route.getLcs().stream().forEach(edgeId -> {
                    // TODO 绘制路由信息
                    TestEdge edge = (TestEdge) graph.getEdge(edgeId);
                    TestVertex start = (TestVertex) edge.getSrc();
                    TestVertex end = (TestVertex) edge.getDst();

                    //start.getCircle().setStroke(Color.BLUE);
                    //start.getCircle().setStrokeWidth(2.0);
                    //end.getCircle().setStroke(Color.BLUE);
                    //end.getCircle().setStrokeWidth(2.0);
                    start.getShape().setHighlight();
                    end.getShape().setHighlight();
                    edge.getShape().setHighlight();
                });
            }
        }

        // 绘制约束条件
        for (TestRequest.Constraint constraint : request.getConstraints()) {
            if (constraint.isVertex()) {
                TestVertex vertex = (TestVertex) graph.getVertex(constraint.getNodeName());
                if (constraint.isForbidden()) {
                    vertex.getShape().setForbidden();
                }
                if (constraint.isMustpass()) {
                    vertex.getShape().setMustpass();
                }
            } else if (constraint.isEdge()) {
                TestEdge edge = (TestEdge) graph.getEdge(constraint.getNodeName());
                if (constraint.isForbidden()) {
                    edge.getShape().setForbidden();
                }
                if (constraint.isMustpass()) {
                    edge.getShape().setMustpass();
                }
            }
        }
    }

    public void setData(TestSchedule data) {
        if (null == data) {
            return;
        }
        this.data = data;
        requestTableView.setItems(data.getRequests());

        // 初始化
        GraphManageController.initGraphView(scrollPane, pane);
    }
}
