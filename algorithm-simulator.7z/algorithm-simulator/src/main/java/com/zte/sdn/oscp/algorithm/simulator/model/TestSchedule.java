package com.zte.sdn.oscp.algorithm.simulator.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

// 测试计划
public class TestSchedule {
    // 标识
    private SimpleBooleanProperty needExecuteSchedule = new SimpleBooleanProperty(true);
    private SimpleStringProperty scheduleName = new SimpleStringProperty("");
    private SimpleStringProperty graphName = new SimpleStringProperty("");
    private SimpleIntegerProperty stockCounts = new SimpleIntegerProperty(0);
    private SimpleIntegerProperty createCounts = new SimpleIntegerProperty(0);
    private SimpleDoubleProperty progress = new SimpleDoubleProperty(0.0);

    // 待创建业务列表
    private ObservableList<TestRequest> requests = FXCollections.observableArrayList();

    public String getScheduleName() {
        return scheduleName.get();
    }

    public void setScheduleName(String scheduleName) {
        this.scheduleName.set(scheduleName);
    }

    public SimpleStringProperty scheduleNameProperty() {
        return scheduleName;
    }

    public String getGraphName() {
        return graphName.get();
    }

    public void setGraphName(String graphName) {
        this.graphName.set(graphName);
    }

    public SimpleStringProperty graphNameProperty() {
        return graphName;
    }

    public int getStockCounts() {
        return stockCounts.get();
    }

    public void setStockCounts(int stockCounts) {
        this.stockCounts.set(stockCounts);
    }

    public SimpleIntegerProperty stockCountsProperty() {
        return stockCounts;
    }

    public int getCreateCounts() {
        return createCounts.get();
    }

    public void setCreateCounts(int createCounts) {
        this.createCounts.set(createCounts);
    }

    public SimpleIntegerProperty createCountsProperty() {
        return createCounts;
    }

    @XmlTransient
    public Double getProgress() {
        return progress.get();
    }

    public void setProgress(Double progress) {
        this.progress.set(progress);
    }

    public SimpleDoubleProperty progressProperty() {
        return progress;
    }

    @XmlElementWrapper(name = "requests")
    @XmlElement(name = "request")
    public ObservableList<TestRequest> getRequests() {
        return requests;
    }

    public TestRequest getRequest(String requestName) {
        for (TestRequest request : getRequests()) {
            if (request.getRequestId().equals(requestName)) {
                return request;
            }
        }
        return null;
    }

    public boolean isNeedExecuteSchedule() {
        return needExecuteSchedule.get();
    }

    public void setNeedExecuteSchedule(boolean needExecuteSchedule) {
        this.needExecuteSchedule.set(needExecuteSchedule);
    }

    public SimpleBooleanProperty needExecuteScheduleProperty() {
        return needExecuteSchedule;
    }
}
