package com.zte.sdn.oscp.algorithm.simulator.controller;

import com.zte.sdn.oscp.algorithm.simulator.model.TestGraph;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;

public class ScheduleCreatePageGraphController extends WizardPageController {

    @FXML
    private ComboBox<String> graphCombo;

    public ScheduleCreatePageGraphController() {
        super("选择或者创建graph", "/images/wolframalpha.png");
    }

    @FXML
    public void initialize() {
    }

    public void init() {
        graphCombo.valueProperty().bindBidirectional(schedule.graphNameProperty());

        // TODO 用combobox绑定, 就不需要这么写了
        // 初始化所有可选graph
        graphCombo.getItems().clear();
        for (TestGraph graph : mainApp.getAllGraphData()) {
            graphCombo.getItems().add(graph.getName());
        }
        // 初始化选中第一个
        graphCombo.getSelectionModel().select(0);
    }

    @Override
    public void handleFinish() {
        schedule.setGraphName(graphCombo.getValue());
    }

    @Override
    public void handleCancel() {

    }

    @FXML
    public void handleGraphManage() {
        mainApp.showGraphManage();

        // 初始化所有可选graph
        graphCombo.getItems().clear();
        for (TestGraph graph : mainApp.getAllGraphData()) {
            graphCombo.getItems().add(graph.getName());
        }
        // 初始化选中第一个
        graphCombo.getSelectionModel().select(0);
    }
}
