package com.zte.sdn.oscp.algorithm.test.examples.controller;

public interface WizardPageControllerExam {

    default void handleFinish() {}
    default void handleCancel() {}

    default String getMsg() {
        return "设置需要显示的信息!";
    }
}
