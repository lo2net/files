package com.zte.sdn.oscp.algorithm.simulator.algorithm;

import com.zte.sdn.oscp.algorithm.simulator.model.TestEdge;
import com.zte.sdn.oscp.algorithm.simulator.model.TestGraph;
import com.zte.sdn.oscp.algorithm.simulator.model.TestVertex;

import edu.uci.ics.jung.graph.util.EdgeType;

public interface GraphGenerator {

    void generateGraph(TestGraph graph);

    default TestEdge addSingleEdge(TestGraph graph, TestVertex vStart, TestVertex vEnd) {
        TestEdge edge = new TestEdge(vStart.getId() + "---" + vEnd.getId(), vStart, vEnd);
        edge.getEdgeAdditionalAttrs().setBwCapacity(Double.valueOf(graph.getBandWidth()));
        edge.getEdgeAdditionalAttrs().setBwUtilization(Double.valueOf(graph.getBandWidth()));
        edge.getEdgeAdditionalAttrs().setBwUnused(Double.valueOf(graph.getBandWidth()));
        edge.getEdgeAdditionalAttrs().setBwUtilization(0); // 0% 带宽利用率
        edge.setWeight(Double.valueOf(graph.getWeight()));
        edge.getEdgeAdditionalAttrs().setDelay(Double.valueOf(graph.getTimeDelay()));
        edge.init();
        graph.addEdge(edge, vStart, vEnd, EdgeType.DIRECTED);

        vStart.getForwardEdges().add(edge);
        vEnd.getBackwardEdges().add(edge);


        return edge;
    }

    default void addEdge(TestGraph graph,
                         int start, double startX, double startY,
                         int end, double endX, double endY) {

        TestVertex vStart = (TestVertex) graph.getVertex(String.valueOf(start));
        vStart.getShape().getCircle().setCenterX(startX);
        vStart.getShape().getCircle().setCenterY(startY);
        TestVertex vEnd = (TestVertex) graph.getVertex(String.valueOf(end));
        vEnd.getShape().getCircle().setCenterX(endX);
        vEnd.getShape().getCircle().setCenterY(endY);
        // 添加边
        TestEdge edge = addSingleEdge(graph, vStart, vEnd);

        // 绘制边
        edge.getShape().calcLinePosition();
        // TODO 双向业务转换成两条单向边
        if (graph.biDirection()) {
            // 添加反向边
            TestEdge reverseEdge = addSingleEdge(graph, vEnd, vStart);
            // 设置正反向关系
            edge.setReverse(reverseEdge);
            reverseEdge.setReverse(edge);
            // 绘制边
            reverseEdge.getShape().calcLinePosition();
        }
    }
}
